<?php
    include("app/theme_func.php");

    $themes = new ThemeFunctions();
    $themes->active_theme();

	require(_BASE_."index.php");

?>