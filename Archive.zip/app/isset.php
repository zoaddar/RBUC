<?php

if(isset($_REQUEST)) {
    require('functions.php');
    $func = new Functions();
    $msg = array();
    # Login
    if(isset($_REQUEST['login']) && isset($_REQUEST['user']) && isset($_REQUEST['pass'])) {
        $username = get_request_val($_REQUEST['user']);
        $password = get_request_val($_REQUEST['pass']);

        try {
            if($username == "") throw new Exception('User ID can not be empty.');
            if($password == "") throw new Exception('Password can not be empty.');
            
            if($func->login($username, $password)) {
                $msg['redirect'] = "index.php?module=home&action=home";
            }
        }
        catch(Exception $e) {
            $msg['error'] = $e->getMessage();
        }
        echo json_encode($msg);
    }
    # Theme Option
    if(isset($_REQUEST['sidebar']) && $_REQUEST['sidebar']==true && $_SESSION['loggedin']==true) {
        $func->ThemeOptions("sidebar");
    }
    if(isset($_REQUEST['uitheme']) && $_REQUEST['uitheme']==true && $_SESSION['loggedin']==true) {
        $func->ThemeOptions("uitheme");
    }
    # Roles Datatable
    if(isset($_REQUEST['roles_tbl']) && $_REQUEST['roles_tbl']==true && $_SESSION['loggedin']==true) {
        $datatbl = new DATATABLE;
        $tbldata = json_decode($datatbl->ROLES_TABLE($_REQUEST), true);

        if($tbldata['status'] == 0) {
            echo json_encode($tbldata['resp']);
        }
    }
    # User Datatable
    if(isset($_REQUEST['users_tbl']) && $_REQUEST['users_tbl']==true && $_SESSION['loggedin']==true) {
        $datatbl = new DATATABLE;
        $tbldata = json_decode($datatbl->USERS_TABLE($_REQUEST), true);

        if($tbldata['status'] == 0) {
            echo json_encode($tbldata['resp']);
        }
    }
    # Pages Datatable
    if(isset($_REQUEST['pages_tbl']) && $_REQUEST['pages_tbl']==true && $_SESSION['loggedin']==true) {
        $datatbl = new DATATABLE;
        $tbldata = json_decode($datatbl->PAGES_TABLE($_REQUEST), true);

        if($tbldata['status'] == 0) {
            echo json_encode($tbldata['resp']);
        }
    }
    # Form submit
    if(isset($_REQUEST['form_submit']) && $_REQUEST['form_submit']==true) {
        # Roles options
        if(isset($_REQUEST['module']) && $_REQUEST['module'] == "settings" && isset($_REQUEST['action']) && $_REQUEST['action'] == "addrole") {
            # Add Role
            if(isset($_REQUEST['add']) && $_REQUEST['add'] == "addrole") {
                $data = form_data($_REQUEST);
                $title = get_value($data['title']);
                $desc  = get_value($data['desc']);

                try {
                    if($title == "") throw new Exception('Role Name can not be empty');
                    if($desc  == "") throw new Exception('Decriptions can not be empty');
                    
                    $rbac = new PhpRbac\Rbac();
                    $hasPerm = $rbac->check("addrole", $_SESSION['user_inf']->id);
                    if(!$hasPerm) die($func->msg(1, "You are not authorize to create Role"));

                    $role_id = $rbac->Roles->add($title, $desc);

                    if($role_id) die($func->msg(0, "Role created successfully"));
                }
                catch(Exception $e) {
                    $msg['error'] = $e->getMessage();
                }
                echo json_encode($msg);
            }
            # Role Update
            if(isset($_REQUEST['redit']) && $_REQUEST['redit'] != "") {
                $func->UPDATE_ROLE(valid_input($_REQUEST['redit']),base64_encode(serialize(form_data($_REQUEST))));
            }
            # Add Permission
            if(isset($_REQUEST['add']) && $_REQUEST['add'] == "addpermission") {
                $data  = form_data($_REQUEST);
                $title = get_value($data['ptitle']);
                $desc  = get_value($data['pdesc']);

                try {
                    if($title == "") throw new Exception('Permission Name can not be empty');
                    if($desc  == "") throw new Exception('Decriptions can not be empty');

                    $rbac = new PhpRbac\Rbac();
                    $hasPerm = $rbac->check("addpermission", $_SESSION['user_inf']->id);
                    if(!$hasPerm) die($func->msg(1, "You are not authorize to create Role"));

                    $perm_id = $rbac->Permissions->add($title, $desc);

                    if($perm_id) die($func->msg(0, "Permission created successfully"));
                }
                catch(Exception $e) {
                    $msg['error'] = $e->getMessage();
                }
                echo json_encode($msg);
            }
            # User Profile Update
            if(isset($_REQUEST['update']) && $_REQUEST['update'] == "user") {
                $func->UPDATE_USER_PROFILE(base64_encode(serialize(form_data($_REQUEST))));
            }
        }
        # User options
        if(isset($_REQUEST['module']) && $_REQUEST['module'] == "users" && isset($_REQUEST['action']) && $_REQUEST['action'] == "employee") {
            # User Create
            $data = form_data($_REQUEST);
            if(isset($_REQUEST['add']) && $_REQUEST['add'] == "adduser") {
                $auth = get_value($data['auth']);
                $user = get_value($data['user']);
                $pass = get_value($data['pass']);
                $role = get_value(isset($data['role']) ? $data['role'] : "");

                try {
                    if($auth == "") throw new Exception('Parameter missing');
                    if($user == "") throw new Exception('User can not be empty');
                    if($pass == "") throw new Exception('Password can not be empty');
                    if($role == "") throw new Exception('Role can not be empty');

                    $add_user = base64_encode(serialize(["action" => "adduser", "auth" => $auth,"user" => $user, "pass" => $pass, "role" => $role]));
                    $resp = json_decode($func->ADD_USER($add_user), true);
                }
                catch(Exception $e) {
                    $msg['error'] = $e->getMessage();
                }
                echo json_encode($msg);
            }
            # User Profile Update
            if(isset($_REQUEST['updateuser'])) {
                $func->UPDATE_USER_PROFILE(base64_encode(serialize($data)));
            }
            # Change Password
            if(isset($_REQUEST['update']) && $_REQUEST['update'] == "chp_user") {
                try {
                    if(get_value($data['n_pass']) == "") throw new Exception('New Password can not be empty');
                    if(get_value($data['r_pass']) == "") throw new Exception('Retype Password can not be empty');
                    if(get_value($data['r_pass']) != get_value($data['n_pass'])) throw new Exception('Retype does not match');
                    
                    $user = get_value($data['user']);
                    $pass = get_value($data['o_pass']);
                    $newpass = get_value($data['r_pass']);

                    $chppass = base64_encode(serialize(["user" => $user, "pass" => $pass, "newpass" => $newpass]));
                    $func->CHANGE_PASS($chppass);
                }
                catch(Exception $e) {
                    $msg['error'] = $e->getMessage();
                }
                echo json_encode($msg);
            }
        }
        # Profile Update
        if(isset($_REQUEST['module']) && isset($_REQUEST['action']) && $_REQUEST['action']=="profile") {
            $data   = form_data($_REQUEST);
            $update = get_value(isset($data['update']) ? $data['update'] : "");
            if($update == "own") {
                $func->UPDATE_PROFILE(base64_encode(serialize(form_data($_REQUEST))));
            }
            # Change Password
            else if($update == "chp_own") {
                try {
                    if(get_value($data['o_pass']) == "") throw new Exception('Old Password can not be empty');
                    if(get_value($data['n_pass']) == "") throw new Exception('New Password can not be empty');
                    if(get_value($data['r_pass']) == "") throw new Exception('Retype Password can not be empty');
                    if(get_value($data['r_pass']) != get_value($data['n_pass'])) throw new Exception('Retype does not match');
                    
                    $pass = get_value($data['o_pass']);
                    $newpass = get_value($data['r_pass']);

                    $chppass = base64_encode(serialize(["user" => $_SESSION['user_inf']->user, "pass" => md5($pass), "newpass" => $newpass]));
                    $func->CHANGE_PASS($chppass);
                }
                catch(Exception $e) {
                    $msg['error'] = $e->getMessage();
                }
                echo json_encode($msg);
            }
        }

        # Page Options
        if(isset($_REQUEST['module']) && $_REQUEST['module'] == "settings" && isset($_REQUEST['action']) && $_REQUEST['action'] == "pages") {
            # Create Page
            if(isset($_REQUEST['add']) && $_REQUEST['add'] == "addpage") {
                $data = form_data($_REQUEST);
                $selected = get_value($data['m_p']);
                # Module
                if($selected == 1) {
                    $m_name  = get_value($data['m_name']);
                    $m_title = get_value($data['m_title']);
                    $m_icon  = get_value($data['m_icon']);
                    $m_access_desc  = get_value($data['m_access_desc']);

                    try {
                        if($m_name  == "") throw new Exception('Module Name can not be empty');
                        if($m_title == "") throw new Exception('Module Title can not be empty');
                        if($m_icon  == "") throw new Exception('Module Icon can not be empty');

                        $page_info = base64_encode(serialize(["user" => $_SESSION['user_inf']->user, "action" => "addmodule", "module" => $m_name, "title" => $m_title, "icons" => $m_icon, "m_access_desc" =>$m_access_desc]));
                        $func->ADD_MODULE($page_info);
                    }
                    catch(Exception $e) {
                        $msg['error'] = $e->getMessage();
                    }
                    echo json_encode($msg);
                }
                # Pages
                if($selected == 2) {
                    $module      = isset($data['pmodule']) ? get_value($data['pmodule']) : "";
                    $p_name      = get_value($data['p_name']);
                    $p_title     = get_value($data['p_title']);
                    $keyword     = get_value($data['keyword']);
                    $description = get_value($data['description']);
                    $custom_css  = get_value($data['custom_css']);

                    try {
                        if($module  == "") throw new Exception('Module can not be empty');
                        if($p_name  == "") throw new Exception('Page Name can not be empty');
                        if($p_title == "") throw new Exception('Page Title can not be empty');

                        $page_info = base64_encode(serialize(["user" => $_SESSION['user_inf']->user, "action" => "addpage", "module" => $module, "pageName" => $p_name, "pageTitle" => $p_title, "keyWord" => $keyword, "description" => $description, "custom_css" => $custom_css]));
                        $func->ADD_PAGE($page_info);
                    }
                    catch(Exception $e) {
                        $msg['error'] = $e->getMessage();
                    }
                    echo json_encode($msg);
                }
            }
            # Update Page
            if(isset($_REQUEST['pedit']) && $_REQUEST['pedit'] != "") {
                $data = form_data($_REQUEST);
                # Update Module
                if(isset($_REQUEST['u_mod']) && $_REQUEST['u_mod'] != "") {
                    $id        = get_value($data['u_mod']);
                    $u_m_title = get_value($data['u_m_title']);
                    $u_m_icon  = get_value($data['u_m_icon']);
                    $publish   = get_value($data['publish']);

                    try {
                        if($publish == "") throw new Exception('Status can not be empty');
                        if($u_m_title == "") throw new Exception('Module Title can not be empty');
                        if($u_m_icon  == "") throw new Exception('Module Icon can not be empty');

                        $page_info = base64_encode(serialize(["user" => $_SESSION['user_inf']->user, "action" => "addmodule", "id" => $id, "title" => $u_m_title, "publish" => $publish, "icons" => $u_m_icon]));
                        $func->UPDATE_MODULE($page_info);
                    }
                    catch(Exception $e) {
                        $msg['error'] = $e->getMessage();
                    }
                    echo json_encode($msg);
                }
                # Update Page
                else if(isset($_REQUEST['u_page']) && $_REQUEST['u_page'] != "") {
                    $module      = isset($data['u_pmodule']) ? get_value($data['u_pmodule']) : "";
                    $id          = get_value($data['u_page']);
                    $p_title     = get_value($data['u_p_title']);
                    $keyword     = get_value($data['u_keyword']);
                    $description = get_value($data['u_description']);
                    $custom_css  = get_value($data['u_custom_css']);
                    $publish     = get_value($data['publish']);

                    try {
                        if($publish == "") throw new Exception('Status can not be empty');
                        if($module  == "") throw new Exception('Module can can not be empty');
                        if($p_title == "") throw new Exception('Page Title can can not be empty');

                        $page_info = base64_encode(serialize(["user" => $_SESSION['user_inf']->user, "action" => "addpage", "id" => $id, "module" => $module, "pageTitle" => $p_title, "keyWord" => $keyword, "description" => $description, "custom_css" => $custom_css, "publish" => $publish]));
                        $func->UPDATE_PAGE($page_info);
                    }
                    catch(Exception $e) {
                        $msg['error'] = $e->getMessage();
                    }
                    echo json_encode($msg);
                }
            }
        }
    }


    if(isset($_REQUEST['acc_name_evnt']) && $_REQUEST['acc_name_evnt'] == true) {
        echo json_encode(array($_REQUEST));
    }

}
?>