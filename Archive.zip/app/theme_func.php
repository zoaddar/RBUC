<?php
    class ThemeFunctions {
        function __construct() {
            ini_set("display_errors", 1);
	
            require('config.php');
            require('common_funcs.php');
        }

        public function active_theme() {
            $db =  $this->db_connect(true);

            $theme = "default";
            $sql = "SELECT ui_theme FROM ".PREFIX."themeoptions WHERE id='1';";
            if ($res = $db->query($sql)) {
                $theme = $res->fetch_assoc()['ui_theme'];
            }
            $db =  $this->db_connect(false);
            
            define("_BASE_", "themes/$theme/");
            define("_FAVICON_", _BASE_."assets/img/favicon.png");

            return true;
        }

        public function db_connect($connect=false) {
            $db = new mysqli(_DBHOST_, _DBUSER_, _DBPASS_, _DBNAME_);
            $db->character_set_name();
            $db->set_charset("utf8");
            if ($db->connect_error) {
                $db = "Failed to connect to MySQL: " . $db->connect_error;
            }
            if(!$connect) $db->close();

            return $db;
        }
    }
?>