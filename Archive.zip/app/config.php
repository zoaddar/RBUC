<?php
	ini_set("display_errors", 1);
	
	$dt = new DateTime('now', new DateTimezone('Asia/Dhaka'));
	define("CURRENT_DATE_TIME", $dt->format('d-m-Y g:i a'));
	define("FORM_ACTION", "?".$_SERVER['QUERY_STRING']);
	define("_PATH_", "http://localhost/zoaddar/mdc-dashboard/");

	define("_DBHOST_", "127.0.0.1");

	define("_DBUSER_", "root");
	define("_DBPASS_", "Kader136420");
	define("_DBNAME_", "zoaddar_sarkarpress");

	// define("_DBUSER_", "netcloud_client");
	// define("_DBPASS_", "Kader_136_420");
	// define("_DBNAME_", "netcloud_client_sarkarpress");

	define("_ADAPTER_", "mysqli");
	define("PREFIX", "ncs_");
?>