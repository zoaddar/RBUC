<?php
    function get_request_val($data) {
        return array_values($data)[0];
    }
    function get_request_title($data) {
        return array_keys($data)[0];
    }

    function get_key_val($data) {
        $array = array();
        foreach($data as $k) {
            $array[] = $k['value'];
        }
        return $array;
    }

    function get_value($data) {
        return valid_input($data[0]['value']);
    }
    function get_title($data) {
        return valid_input($data[0]['title']);
    }
    function get_display($data) {
        return valid_input($data[0]['display']);
    }

    function valid_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);

        return $data;
    }
    
    function form_data($REQUEST) {
        $formdata = array();
        foreach ($REQUEST as $key => $data) {
            if(!is_array($data)) continue;
            foreach ($data as $k => $v) {
                if(is_numeric($k)) {
                    $idata = json_decode(base64_decode(valid_input($v)), true);
                    $formdata[$key][] = $idata;
                }
                else {
                    $formdata[$key][] = array("title" => $k, "value" => valid_input($v));
                }
            }

        }
        return $formdata;
    }
?>