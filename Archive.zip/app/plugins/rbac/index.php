<?php
    #require 'vendor/autoload.php';
    require_once('autoload.php');

    ini_set("display_errors", true);

    $rbac = new PhpRbac\Rbac();
    #use PhpRbac\Rbac;
    #$rbac = new Rbac();
    #$rbac = new \PhpRbac\Rbac();

    echo"<pre>";
    #print_r($rbac->Permissions);
    #print_r($rbac->Roles);
    #print_r($rbac->Users);

    // $role_id = $rbac->Roles->add('employee', 'User can modify profile');
    // $rbac->Users->assign($role_id, 3);

    $role_id = $rbac->Roles->returnId('root');
    // $role_id = $rbac->Roles->returnId('manager');
    // $role_id = $rbac->Roles->returnId('employee');


    // $perm_id = $rbac->Permissions->add('root', 'Have access system');
    // $perm_id = $rbac->Permissions->add('home', 'Dashboard');
    // $perm_id = $rbac->Permissions->add('settings', 'Settings Module');
    // $perm_id = $rbac->Permissions->add('users', 'Access Users Module');
    // $perm_id = $rbac->Permissions->add('profile', 'Profile');
    // $perm_id = $rbac->Permissions->add('addpage', 'Manage Pages');
    // $perm_id = $rbac->Permissions->add('pages', 'Menu Management');
    // $perm_id = $rbac->Permissions->add('addmodule', 'Manage Module');
    // $perm_id = $rbac->Permissions->add('employee', 'Employee list');
    // $perm_id = $rbac->Permissions->add('addrole', 'Add role');
    // $perm_id = $rbac->Permissions->add('adduser', 'Manage Users');
    // $perm_id = $rbac->Permissions->add('addpermission', 'Manage Permission');

    // $rbac->Roles->assign($role_id, 1);
    // $rbac->Roles->assign($role_id, 2);
    // $rbac->Roles->assign($role_id, 3);
    // $rbac->Roles->assign($role_id, 4);
    // $rbac->Roles->assign($role_id, 5);
    // $rbac->Roles->assign($role_id, 6);
    // $rbac->Roles->assign($role_id, 7);
    // $rbac->Roles->assign($role_id, 8);
    // $rbac->Roles->assign($role_id, 9);
    // $rbac->Roles->assign($role_id, 10);
    // $rbac->Roles->assign($role_id, 11);


    // $hasPerm = $rbac->check('test', 2);
    // echo $hasPerm;


    // Get Entity Id's
    #$perm_id = $rbac->Permissions->returnId('delete_own_posts');

    // Assign Role to User (The UserID is provided by the application's User Management System)
    #$rbac->Users->assign($role_id, 4);

    // Edit Entities
    #$rbac->Permissions->edit($perm_id, 'delete_posts', 'Can delete posts they create');
    #$rbac->Roles->edit('blog_spam_moderator', 'User is responsible for spam moderation');

    // Remove single Permission
    #$rbac->Permissions->remove($perm_id);

    // Remove Permission and all descendants
    #$rbac->Permissions->remove($perm_id, true);

    // Unassign a single Permission/Role assignment using Titles.
    // The following are equivalent statements.
    #$rbac->Permissions->unassign('blog_moderator', 'delete_posts');
    #$rbac->Roles->unassign('blog_moderator', 'delete_posts');

    // Make sure User has 'blog_moderator' Role
    #$hasRole = $rbac->Users->hasRole($role_id, 2);

    // Check to see if User has 'delete_own_posts' Permission
    #$hasPermission = $rbac->check('delete_own_posts', 2);

    // Will return a 403 HTTP status code and an 'Access Denied' message if User does not have Role
    #$enforce = $rbac->enforce('delete_own_posts', 2);

    // Unassign 'blog_user' Role assigned to a User using the Role's Path
    #$rbac->Users->unassign('blog_moderator', 2);

    #print_r($hasPermission);
?>