<?php
define("_DBHOST_", "127.0.0.1");
define("_DBUSER_", "root");
define("_DBPASS_", "Kader136420");
define("_DBNAME_", "zoaddar_ssp");

$table = 'user';
$primaryKey = 'id';

$JoinColumns = array(
	array( 'db' => '`u`.`first_name`', 'dt' => 0, 'field' => 'first_name' ),
	array( 'db' => '`u`.`last_name`',  'dt' => 1, 'field' => 'last_name' ),
	array( 'db' => '`u`.`position`',   'dt' => 2, 'field' => 'position' ),
	array( 'db' => '`u`.`office`',     'dt' => 3, 'field' => 'office'),
	array( 'db' => '`ud`.`email`',     'dt' => 4, 'field' => 'email' ),
	array( 'db' => '`ud`.`phone`',     'dt' => 5, 'field' => 'phone' ),
	array( 'db' => '`u`.`start_date`', 'dt' => 6, 'field' => 'start_date', 'formatter' => function($d, $row) {
		return date( 'jS M y', strtotime($d));
	}),
	array('db'  => '`u`.`salary`', 'dt' => 7, 'field' => 'salary', 'formatter' => function($d, $row) {
		return '$'.number_format($d);
	})
);
$joinQuery = "FROM `user` AS `u` JOIN `user_details` AS `ud` ON (`ud`.`user_id` = `u`.`id`)";
$extraWhere = "u.`salary` >= 90000";
$groupBy = "`u`.`office`";
$having = "`u`.`salary` >= 140000";

$columns = array(
	array( 'db' => 'first_name', 'dt' => 0 ),
	array( 'db' => 'last_name',  'dt' => 1 ),
	array( 'db' => 'last_name',   'dt' => 2 ),
	array( 'db' => 'position',   'dt' => 3 ),
	array( 'db' => 'office',   'dt' => 4 ),
	array( 'db' => 'start_date',   'dt' => 5 ),
	array( 'db' => 'age',   'dt' => 6 ),
	array( 'db' => 'salary',   'dt' => 7 ),
);
$Where = "office = 'London'";

echo DATATABLE($_REQUEST,$table,$primaryKey,$columns,$Where);

function DATATABLE($request,$table,$primaryKey,$columns,$extraWhere='',$joinQuery='',$groupBy='',$having='') {
	$db = array('user' => _DBUSER_,'pass' => _DBPASS_, 'db' => _DBNAME_,'host' => _DBHOST_);

	require('../../ssp.php' );
	return json_encode(SSP::simple($request,$db,$table,$primaryKey,$columns,$joinQuery,$extraWhere,$groupBy,$having));
}