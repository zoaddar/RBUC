<?php
/********************************
	0 = success
	1 = Auth fail,
	2 = permission fail,
	3 = role fail,
	4 = not allow,
	5 = mysql error
	6 = does not exist
	7 = invalid
	8 = failed
	9 = empty
********************************/

class Functions {
	function __construct() {
		session_start();

		require('config.php');
		require('plugins/rbac/autoload.php');
		require('common_funcs.php');
		require('form_funcs.php');
		require('data_table.php');
	}

	public function db_connect($connect=false) {
		$db = new mysqli(_DBHOST_, _DBUSER_, _DBPASS_, _DBNAME_);
		$db->character_set_name();
		$db->set_charset("utf8");
		if ($db->connect_error) {
			$db = "Failed to connect to MySQL: " . $db->connect_error;
		}
		if(!$connect) $db->close();

		return $db;
	}

	public function ThemeOptions($query) {
		$db =  $this->db_connect(true);
		$row = array();

		if($query == "fetch") {
			$sql = "SELECT * FROM ".PREFIX."themeoptions WHERE id='1';";
			if ($res = $db->query($sql)) {
				$row = $res->fetch_assoc();
			}
		}
		if($query == "uitheme") {
			if(isset($_REQUEST['activetheme'])) {
				$activetheme = valid_input($_REQUEST['activetheme']);
				$sql = "UPDATE ".PREFIX."themeoptions SET `ui_theme`='".$activetheme."' WHERE id='1';";
				$res = $db->query($sql);
			}
			else {
				$ui_theme = $this->ThemeOptions("fetch")['ui_theme'];
				foreach(scandir("../themes/", 1) as $thm) {
					if(strpos($thm, '.', 0) !== false) continue;
					echo '<li id="'.$thm.'" '; echo ($ui_theme == $thm) ? 'class="actv"' : '';
					echo '><a title="'.$thm.'" class="uitheme switch-trigger" href="javascript:void(0)">';
					echo '<img src="'.glob("../themes/$thm/*.jpg")[0].'" alt=""/></a></li>';
				}
			}
		}
		if($query == "sidebar") {
			$userData = $this->get_user($_SESSION['user_inf']->user, "themeOptions");
			$themeOptions = json_decode($userData['themeOptions'], true);
			$res = 0;
			if(isset($_REQUEST['sidebarOpt']) && $_REQUEST['sidebarOpt'] !='') {
				$req = explode("|", valid_input($_REQUEST['sidebarOpt']));
				if(array_key_exists($req[0], $themeOptions)) {
					$update = json_encode(array_replace($themeOptions, array($req[0] => $req[1])));
					$sql = "UPDATE ".PREFIX."user SET `themeOptions`='".$update."' WHERE user='".$_SESSION['user_inf']->user."';";
					$res = $db->query($sql);
				}
			}
			echo ($res==1) ? json_encode(array("success" => $res)) : json_encode(array("error" => $res));
		}
		$this->db_connect(false);

		return $row;
	}

	public function get_menu() {
		$rbac = new PhpRbac\Rbac();
		$db = $this->db_connect(true);
		$menu = $page_info = $uInfo = array();

		$sql = "SELECT id,module,title,icons FROM ".PREFIX."module WHERE publish='1' ORDER BY menu_order;";
		if ($res = $db->query($sql)) {
			while($row = $res->fetch_assoc()) {
				$module = $row['module'];
				// Check Roles
				if(!$rbac->check($module, $_SESSION['user_inf']->id)) continue;
				$page_info['module'][$module] = $row;

				$sub_menu = array();
				$sql = "SELECT * FROM ".PREFIX."page WHERE module='$row[id]' AND publish='1';";
				if ($sr = $db->query($sql)) {
					while($srw = $sr->fetch_assoc()) {
						// Check permissions
						if(!$rbac->check($srw['pageName'], $_SESSION['user_inf']->id)) continue;
						$page_info['page'][$srw["pageName"]] = $srw;

						if($srw['mini'] != '' && $srw['mini'] != null) {
							$sub_menu[] = array(
								"href"   => "?module=$module&action=$srw[pageName]",
								"mini"   => $srw['mini'],
								"normal" => $srw['pageTitle']
							);
						}
					}
				}
				$href = (is_array($sub_menu) && count($sub_menu)>0) ? "#$module" : "?module=home&action=$module";
	
				$menu[$row['title']] = array(
					'href'  => $href,
					'icons' => $row['icons'],
					's_item'=> $sub_menu,
				);
			}

			$us = "SELECT * FROM ".PREFIX."user WHERE user='".$_SESSION['user_inf']->user."' AND publish='1';";
			if ($ru = $db->query($us)) {
				$uInfo = $ru->fetch_assoc();
			}
		}
		$this->db_connect(false);

		return array("menu" => $menu, "page_info" => $page_info, "user_info" => $uInfo);
	}

	public function get_user($username, $clm="", $all=false) {
		try {
			$db = $this->db_connect(true);
			$select  = ($clm!="") ? $clm : "id,user,role,additional_info,pass";
			$alluser = ($all == false) ? "AND publish='1'" : "";
			if ($res = $db->query("SELECT $select FROM ".PREFIX."user WHERE user='$username' $alluser;")) {
				return $res->fetch_assoc();
			}
			$db = $this->db_connect(false);
		} catch(PDOException $e) {
			echo json_encode(array("error" => $e->getMessage()));
		}
	}

	public function login($username, $password) {
		$row = $this->get_user(valid_input($username));
		if(!$row) {
			die(json_encode(array("error" => "User ID does not exit !")));
		}
		else {
			$newpass = md5($password);
			if($newpass == $row['pass']) {
				$_SESSION['loggedin'] = true;
				$_SESSION['user_inf'] = (object) array("id"=>$row['id'],"user"=>$row['user'],"role"=>$row['role']);
				
				return true;
			}
			else {
				die(json_encode(array("error" => "Password is not valid !")));
			}
		}
	}

	public function GET_PROFILE($data) {
		$data = unserialize(base64_decode($data));
		$row = $this->get_user(valid_input($data['user']), "*");

		if($row) {
			if($data['pass'] == $row['pass']) {
				if(isset($data['xkey'])) {
					$additional_info = $row['additional_info'];
					if($additional_info != "" || $additional_info != NULL) {
						$additional  = json_decode(base64_decode($additional_info), true);
		
						if(array_key_exists($data['xkey'], $additional)) {
							$result = array_replace($row, array("additional_info" => $additional[$data['xkey']]));
						}
						else die($this->msg(6, "The xkey '{$data["xkey"]}' not found"));
					}
				}
				else $result = $row;
				
				return $this->msg(0, $result);
			}
			else die($this->msg(6, "Password is invalid !"));
		}
		else die($this->msg(6, "User ID does not exit !"));
	}

	public function UPDATE_USER_PROFILE($data) {
		$data = unserialize(base64_decode($data));

		$user 	 = get_value($data['chguser']);
		$role 	 = isset($data['chgrole']) ? get_value($data['chgrole']) : "";
		$publish = isset($data['chgstatus']) ? get_value($data['chgstatus']) : "";
		$name 	 = get_value($data['chgname']);
		$email 	 = get_value($data['chgemail']);
		$mobile  = get_value($data['chgmob']);
		$company = get_value($data['chgcompany']);
		$address = get_value($data['chgaddress']);

		try {
			if($user == "") throw new Exception('User can not be empty');
			if($name == "") throw new Exception('Name can not be empty');
			if($email == "") throw new Exception('Email can not be empty');
			if($mobile == "") throw new Exception('Mobile can not be empty');
			if($role == "") throw new Exception('Role can not be empty');
			if($publish == "") throw new Exception('Status can not be empty');
		}
		catch(Exception $e) {
			die($this->msg(9, $e->getMessage()));
		}

		$uploadOk 	= 0;
		$photo=$sql = "";
		$target_dir = "../adm/uploads/";

		$rbac = new PhpRbac\Rbac();
		$userid = $this->get_user($user, "id")['id'];
		$role_id = $rbac->Roles->returnId($role);
		
		$userroles = $this->GET_DATA("userroles", "RoleID", "WHERE UserID='$userid'");

		$db = $this->db_connect(true);
		if(count($userroles) > 0) {
			$sql = "UPDATE ".PREFIX."userroles SET `RoleID`='$role_id' WHERE UserID='$userid';";
			$db->query($sql);
		}
		else {
			$rbac->Users->assign($role_id, $userid);
		}

		if(!empty($_FILES)) {
			$target_file = $target_dir . basename($_FILES["chgimg"]["name"]);
			$imgFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
			$check		 = !empty($_FILES["chgimg"]["tmp_name"]) ? getimagesize($_FILES["chgimg"]["tmp_name"]) : die($this->msg(7, "Corrupted image !"));

			if($check === false) die($this->msg(7, "File is not an image !"));
			if($_FILES["chgimg"]["size"] > 100000) {
				// die($this->msg(7, "Sorry, your file is too large !"));
			}
			if($imgFileType != "jpg" && $imgFileType != "png" && $imgFileType != "jpeg" && $imgFileType != "gif" ) {
				die($this->msg(7, "Sorry, only JPG, JPEG, PNG & GIF files are allowed"));
			}

			if (move_uploaded_file($_FILES["chgimg"]["tmp_name"], $target_dir.$user .".". $imgFileType)) {
				include("plugins/img_resizer/resizer.php");

				$photo = $target_dir.$user .".". $imgFileType;
				$resizeObj = new resize($photo);
				$resizeObj -> resizeImage(240, 300, 'crop'); #(options: exact, portrait, landscape, auto, crop)
				$resizeObj -> saveImage($photo, 50);
				$uploadOk = 1;
			}
			else {
				$uploadOk = 0;
			}
			if($uploadOk == 1) {
				$sql = "UPDATE ".PREFIX."user SET `role`='$role',`email`='$email',`name`='$name',`mobile`='$mobile',`address`='$address',`photo`='$photo', `company`='$company', `publish`='$publish' WHERE user='$user';";
			}
		}
		else {
			$sql = "UPDATE ".PREFIX."user SET `role`='$role',`email`='$email',`name`='$name',`mobile`='$mobile',`address`='$address', `company`='$company', `publish`='$publish' WHERE user='$user';";
		}

		($db->query($sql) === TRUE) ? die($this->msg(0, "User Updated successfully")) : die($this->msg(5, $db->error));
		$this->db_connect(false);
	}

	#Role Update
	public function UPDATE_ROLE($id, $data) {
		$data = unserialize(base64_decode($data));
		$role  = get_value($data['o_role']);
		$title = get_value($data['u_title']);
		$desc  = get_value($data['u_desc']);

		try {
			if($title == "") throw new Exception('Role Name can not be empty');
			if($desc  == "") throw new Exception('Decriptions can not be empty');
			
			$rbac = new PhpRbac\Rbac();
			$role_id = $rbac->Roles->edit($id, $title, $desc);

			$db = $this->db_connect(true);
			$sql = "UPDATE ".PREFIX."user SET role='$title' WHERE role='$role';";
			$succ = ($db->query($sql) === TRUE) ? 1 : die($this->msg(5, $db->error));
			
			if($succ > 0) {
				$permissions = $this->GET_DATA("permissions", "ID", "ORDER BY Description ASC");
				foreach($permissions as $perm) {
					if(!in_array($perm['ID'], get_key_val($data['perm']))) {
						$sql = "DELETE FROM ".PREFIX."rolepermissions WHERE RoleID='$id' AND PermissionID='$perm[ID]';";
						$db->query($sql);
					}
					else {
						$rbac->Roles->assign($id, $perm['ID']);
					}
				}
				die($this->msg(0, "Role Updated successfully"));
			}
			$this->db_connect(false);
		}
		catch(Exception $e) {
			die($this->msg(9, $e->getMessage()));
		}
	}
	# Update Profile
	public function UPDATE_PROFILE($data) {
		$data = unserialize(base64_decode($data));
		$user 	 = $_SESSION['user_inf']->user;
		$name 	 = get_value($data['chgname']);
		$email 	 = get_value($data['chgemail']);
		$mobile  = get_value($data['chgmob']);
		$address = get_value($data['chgaddress']);

		try {
			if($user == "") throw new Exception('User can not be empty');
			if($name == "") throw new Exception('Name can not be empty');
			if($email == "") throw new Exception('Email can not be empty');
			if($mobile == "") throw new Exception('Mobile can not be empty');
		}
		catch(Exception $e) {
			die($this->msg(9, $e->getMessage()));
		}

		$uploadOk 	= 0;
		$photo=$sql = "";
		$target_dir = "../adm/uploads/";

		if(!empty($_FILES)) {
			$target_file = $target_dir . basename($_FILES["chgphoto"]["name"]);
			$imgFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
			$check		 = !empty($_FILES["chgphoto"]["tmp_name"]) ? getimagesize($_FILES["chgphoto"]["tmp_name"]) : die($this->msg(7, "Corrupted image !"));

			if($check === false) die($this->msg(7, "File is not an image !"));
			if($_FILES["chgphoto"]["size"] > 100000) {
				// die($this->msg(7, "Sorry, your file is too large !"));
			}
			if($imgFileType != "jpg" && $imgFileType != "png" && $imgFileType != "jpeg" && $imgFileType != "gif" ) {
				die($this->msg(7, "Sorry, only JPG, JPEG, PNG & GIF files are allowed"));
			}

			if (move_uploaded_file($_FILES["chgphoto"]["tmp_name"], $target_dir.$user .".". $imgFileType)) {
				include("plugins/img_resizer/resizer.php");

				$photo = $target_dir.$user .".". $imgFileType;
				$resizeObj = new resize($photo);
				$resizeObj -> resizeImage(240, 300, 'crop'); #(options: exact, portrait, landscape, auto, crop)
				$resizeObj -> saveImage($photo, 50);
				$uploadOk = 1;
			}
			else {
				$uploadOk = 0;
			}
			if($uploadOk == 1) {
				$sql = "UPDATE ".PREFIX."user SET `email`='$email',`name`='$name',`mobile`='$mobile',`address`='$address',`photo`='$photo' WHERE user='$user';";
			}
		}
		else {
			$sql = "UPDATE ".PREFIX."user SET `email`='$email',`name`='$name',`mobile`='$mobile',`address`='$address' WHERE user='$user';";
		}

		$db = $this->db_connect(true);
		($db->query($sql) === TRUE) ? die($this->msg(0, "User Updated successfully")) : die($this->msg(5, $db->error));
		$this->db_connect(false);
	}
	# Add User
	public function ADD_USER($data) {
		$data = unserialize(base64_decode($data));
		$auth = explode("-", base64_decode($data['auth']));

		$row = $this->get_user(valid_input($auth[0]), "id,user,role,pass,themeOptions,company,logo,favicon");
		if(!$row || ($row['pass'] != $auth[1])) {
			die($this->msg(1, "You are not Authorize"));
		}
		else {
			$chk_additional = false; $additional_info = "";

			$rbac = new PhpRbac\Rbac();
			$checkRefer = $rbac->Roles->returnId(valid_input($auth[0]));
			$createPerm = $rbac->check("adduser", $row['id']);
			$role_id  	= $rbac->Roles->returnId(valid_input($data['role']));

			if(!$createPerm) die($this->msg(2, "Permission denied to create user"));
			if(!$role_id) die($this->msg(3, "User role does not exist in database"));
			if($checkRefer >= $role_id) die($this->msg(4, "You can not create upper/same level user then you"));

			$user    = valid_input($data['user']);
			$pass    = md5(valid_input($data['pass']));
			$role    = valid_input($data['role']);
			$refered = valid_input($auth[0]);
			$theme   = $row['themeOptions'];
			$company = $row['company'];
			$logo 	 = $row['logo'];
			$favicon = $row['favicon'];

			$db =  $this->db_connect(true);
			$sql = "INSERT INTO ".PREFIX."user(user,pass,role,refered_by,themeOptions,company,logo,favicon) ";
			$sql.= "VALUES('$user','$pass','$role','$refered','$theme','$company','$logo','$favicon') ";
			$sql.= "ON DUPLICATE KEY UPDATE user='$user', role='$role', pass='$pass';";

			$last_id = ($db->query($sql) === TRUE) ? $db->insert_id : die($this->msg(5, $db->error));
			$this->db_connect(false);
			
			if($last_id > 0) {
				$rbac->Users->assign($role_id, $last_id);
				die($this->msg(0, "User created successfully"));
			}
		}
	}
	# Add page
	public function ADD_PAGE($data) {
		$data = unserialize(base64_decode($data));
		$user = $data['user'];

		$row = $this->get_user($user, "role");
		if(!$row) {
			die($this->msg(1, "You are not Authorize"));
		}
		else {
			$rbac = new PhpRbac\Rbac();

			$role_id = $rbac->Roles->returnId($row['role']);
			$hasPerm = $rbac->check($data['action'], $role_id);
			if(!$hasPerm) die($this->msg(2, "Permission denied to add Page"));

			$perm_id = $rbac->Permissions->add($data['pageName'], isset($data['p_access_desc']) ? $data['p_access_desc'] : $data['pageTitle']);

			unset($data['p_access_desc']);
			unset($data['action']);
			unset($data['user']);

			$db = $this->db_connect(true);
			$order = $this->GET_DATA("page", "MAX(page_order) AS page_order")[0];
			$page_order = $order['page_order']+1;

			$clm = implode(",", array_keys($data)) .",mini,Author,page_order";
			$val = "'".implode("','", array_values($data)) ."','". ucfirst($data['pageTitle'][0])."','$user','$page_order'";

			$sql = "INSERT INTO ".PREFIX."page ($clm) VALUES ($val);";
			$this->db_connect(false);
			$succ = ($db->query($sql) === TRUE) ? 1 : die($this->msg(5, $db->error));

			if($succ == 1) {
				// $rbac->Roles->assign($role_id, $perm_id);
				die($this->msg(0, "Page created successfully"));
			}
		}
	}
	# Update page
	public function UPDATE_PAGE($data) {		
		$data = unserialize(base64_decode($data));
		$user = $data['user'];

		$row = $this->get_user($user, "role");
		if(!$row) {
			die($this->msg(1, "You are not Authorize"));
		}
		else {
			$rbac = new PhpRbac\Rbac();
			$role_id = $rbac->Roles->returnId($row['role']);
			$hasPerm = $rbac->check($data['action'], $role_id);
			if(!$hasPerm) die($this->msg(2, "Permission denied to update Page"));


			$clm ="";
			foreach($data as $k => $v) {
				if($k == "id" || $k == "user" || $k == "action") continue;
				$clm.= "$k='$v',";
			}

			$db  = $this->db_connect(true);
			$sql = "UPDATE ".PREFIX."page SET ". rtrim($clm,',') ." WHERE id='$data[id]';";
			$msg = ($db->query($sql) === TRUE) ? die($this->msg(0, "Page Updated successfully")) : die($this->msg(5, $db->error));
			$this->db_connect(false);
		}
	}
	# Add Module
	public function ADD_MODULE($data) {
		$data = unserialize(base64_decode($data));
		$user = $data['user'];

		$row = $this->get_user($user, "role");
		if(!$row) {
			die($this->msg(1, "You are not Authorize"));
		}
		else {
			$rbac = new PhpRbac\Rbac();

			$role = $row['role'];
			$role_id = $rbac->Roles->returnId($role);
			$hasPerm = $rbac->check($data['action'], $role_id);
			if(!$hasPerm) die($this->msg(2, "Permission denied to add Module"));

			$perm_id = $rbac->Permissions->add($data['module'], isset($data['m_access_desc']) ? $data['m_access_desc'] : $data['title']);
		
			unset($data['m_access_desc']);
			unset($data['action']);
			unset($data['user']);

			$db = $this->db_connect(true);

			$morder = $this->GET_DATA("module", "MAX(menu_order) AS menu_order")[0];
			$menu_order = $morder['menu_order']+1;
			$porder = $this->GET_DATA("page", "MAX(page_order) AS page_order")[0];
			$page_order = $porder['page_order']+1;

			$clm = implode(",", array_keys($data)) .",menu_order";
			$val = "'".implode("','", array_values($data)) ."','$menu_order'";
			$sql = "INSERT INTO ".PREFIX."module ($clm) VALUES ($val);";
			$last_id = ($db->query($sql) === TRUE) ? $db->insert_id : die($this->msg(5, $db->error));
			if($last_id > 0) {
				$pageName = $data['module'];
				$pageTitle = $data['title'];

				$psql = "INSERT INTO ".PREFIX."page (module,pageName,pageTitle,page_order,Author) ";
				$psql.= "VALUES ('$last_id','$pageName','$pageTitle','$page_order','$user');";
				$db->query($psql);
				$this->db_connect(false);

				$rbac->Roles->assign($role_id, $perm_id);
				die($this->msg(0, "Module created successfully"));
			}
		}
	}
	# Update Module
	public function UPDATE_MODULE($data) {
		$data = unserialize(base64_decode($data));
		$user = $data['user'];

		$row = $this->get_user($user, "role");
		if(!$row) {
			die($this->msg(1, "You are not Authorize"));
		}
		else {
			$rbac = new PhpRbac\Rbac();

			$role = $row['role'];
			$role_id = $rbac->Roles->returnId($role);
			$hasPerm = $rbac->check($data['action'], $role_id);
			if(!$hasPerm) die($this->msg(2, "Permission denied to update Module"));

			$clm ="";
			foreach($data as $k => $v) {
				if($k == "id" || $k == "user" || $k == "action") continue;
				$clm.= "$k='$v',";
			}

			$db  = $this->db_connect(true);
			$sql = "UPDATE ".PREFIX."module SET ". rtrim($clm,',') ." WHERE id='$data[id]';";
			$msg = ($db->query($sql) === TRUE) ? die($this->msg(0, "Module Updated successfully")) : die($this->msg(5, $db->error));
			$this->db_connect(false);
		}
	}
	# Set additional info
	public function SET_ADDITIONAL($data) {
		$data = unserialize(base64_decode($data));
		$auth = explode("-", base64_decode($data['auth']));

		$row = $this->get_user(valid_input($auth[0]), "id,user,pass");
		if(!$row || ($row['pass'] != $auth[1])) {
			die($this->msg(1, "You are not Authorize"));
		}
		$ifexist = $this->get_user(valid_input($data['user']), "user,role,additional_info");
		if(!$ifexist) die($this->msg(6, "User does not exist"));
		else {
			$additional = array();

			$rbac = new PhpRbac\Rbac();
			$role_id  = $rbac->Roles->returnId(valid_input($ifexist['role']));
			
			$xkeyPerm = $rbac->check($data['xkey'], $row['id']);
			$perm_id  = $rbac->Permissions->returnId($data['xkey']);

			if(!$xkeyPerm) die($this->msg(2, "Permission denied to set xkey"));

			$additional_info = $ifexist['additional_info'];
			if($additional_info != "" || $additional_info != NULL) {
				$additional = json_decode(base64_decode($additional_info), true);

				if(array_key_exists($data['xkey'], $additional)) {
					$additional = array_replace($additional, array($data['xkey'] => $data['xval']));
				}
				else {
					$additional = array_merge($additional, array($data['xkey'] => $data['xval']));
				}
			}
			else {
				$additional = array($data['xkey'] => $data['xval']);
			}
			// return $additional;
			$result = base64_encode(json_encode($additional));
			
			$db =  $this->db_connect(true);
			$user = valid_input($data['user']);
			$sql = "UPDATE ".PREFIX."user SET additional_info='$result'  WHERE `user`='$user';";
			if($db->query($sql) === TRUE) {
				$rbac->Roles->assign($role_id, $perm_id);
				return $this->msg(0, "The xkey='{$data["xkey"]}' & xval='{$data["xval"]}' set successfully");
			}
			else return $this->msg(5, $db->error);
			$this->db_connect(false);
		}
	}
	
	public function DEL_ADDITIONAL($data) {
		$data = unserialize(base64_decode($data));
		$auth = explode("-", base64_decode($data['auth']));

		$row = $this->get_user(valid_input($auth[0]), "user,pass");
		if(!$row || ($row['pass'] != $auth[1])) {
			die($this->msg(1, "You are not Authorize"));
		}
		$ifexist = $this->get_user(valid_input($data['user']), "user,role,additional_info");
		if(!$ifexist) die($this->msg(6, "User does not exist"));
		else {
			$rbac = new PhpRbac\Rbac();

			$additional = array();
			$checkRefer = $rbac->Roles->returnId(valid_input($auth[0]));
			$xkeyPerm   = $rbac->check($data['xkey'], $checkRefer);
			$role_id  	= $rbac->Roles->returnId(valid_input($ifexist['role']));
			$perm_id 	= $rbac->Permissions->returnId($data['xkey']);

			if(!$xkeyPerm) die($this->msg(2, "Permission denied to delete xkey"));

			$additional_info = $ifexist['additional_info'];
			if($additional_info != "" || $additional_info != NULL) {
				$display_add = json_decode(base64_decode($additional_info), true);
				$additional  = json_decode(base64_decode($additional_info), true);

				if(array_key_exists($data['xkey'], $additional)) {
					unset($additional[$data['xkey']]);
					$result = base64_encode(json_encode($additional));
					
					$db =  $this->db_connect(true);
					$user = valid_input($data['user']);
					$sql = "UPDATE ".PREFIX."user SET additional_info='$result'  WHERE `user`='$user';";
					if($db->query($sql) === TRUE) {
						$rbac->Roles->assign($role_id, $perm_id);
						return $this->msg(0, "The xkey='{$data["xkey"]}' & xval='{$display_add[$data["xkey"]]}' delete successfully");
					}
					else return $this->msg(5, $db->error);
					$this->db_connect(false);
				}
				else die($this->msg(6, "The xkey '{$data["xkey"]}' does not exist for '{$data["user"]}'"));
			}
			else die($this->msg(6, "The xkey '{$data["xkey"]}' does not exist for '{$data["user"]}'"));
		}
	}

	public function CHANGE_PASS($data) {
		$data = unserialize(base64_decode($data));

		$row = $this->get_user(valid_input($data['user']), "user,pass");
		if(!$row) die($this->msg(6, "User name does not exist"));
		else {
			if($row['pass'] != $data['pass']) die($this->msg(6, "Old password is invalid !"));
			$db =  $this->db_connect(true);
			$user  = valid_input($data['user']);
			$nPass = md5(valid_input($data['newpass']));
			$sql = "UPDATE ".PREFIX."user SET pass='$nPass'  WHERE `user`='$user';";

			return ($db->query($sql) === TRUE) ? die($this->msg(0, "Password changed successfully")) : die($this->msg(5, $db->error));
			$this->db_connect(false);
		}
	}

	public function GET_DATA($tbl, $clm="", $extra="") {
		try {
			$db = $this->db_connect(true);
			$select  = ($clm != "") ? $clm : "*";

			$data = array();
			if ($res = $db->query("SELECT $clm FROM ".PREFIX."$tbl $extra;")) {
				while($row = $res->fetch_assoc()) {
					$data[] = $row;
				}
			}
			$db = $this->db_connect(false);
			return $data;

		} catch(PDOException $e) {
			echo json_encode(array("error" => $e->getMessage()));
		}
	}

	public function HTTP_REQUEST($url, $param) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($param));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		$result = curl_exec($ch);
		curl_close ($ch);

        return $result;
	}
	
	public function msg($status, $msg) {
		return json_encode(array("status" => "$status", "resp" => $msg));
	}

	public function is_logged_in() {
		if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
			return true;
		}
	}
	public function logout() {
		unset($_SESSION['loggedin']);
		unset($_SESSION['username']);
		session_destroy();
	}
}
?>