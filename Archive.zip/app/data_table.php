<?php
    class DATATABLE {
        # Role's Table
        public function ROLES_TABLE($request) {
            $table=$primaryKey=$columns=$Where=$joinQuery=$groupBy=$having='';
    
            if(isset($request['roles_tbl'])) {
                $table = PREFIX."roles"; $primaryKey= "ID";
                $columns = array(
                    array( 'db' => 'ID', 'dt' => 0, 'formatter' => function($d, $row) {
                        return "<a title=\"Edit\" href=\"?module=settings&action=addrole&redit=$d\"># $d</a>";
                    }),
                    array( 'db' => 'Title',	      'dt' => 1),
                    array( 'db' => 'Description', 'dt' => 2)
                );
            }
            return $this->msg(0, $this->JSON_TABLE_DATA($request,$table,$primaryKey,$columns,$Where,$joinQuery,$groupBy,$having));
        }
        # User's Table
        public function USERS_TABLE($request) {
            $table=$primaryKey=$columns=$Where=$joinQuery=$groupBy=$having='';
    
            if(isset($request['users_tbl'])) {
                $table = PREFIX."user"; $primaryKey= "id";
                $Where = "refered_by='".$request['users_tbl'] ."' AND user <>'".$request['users_tbl']."'";
                $columns = array(
                    array( 'db' => 'photo','dt' => 0, 'formatter' => function($d, $row) {
                        $img = ($d!='' && $d!= null) ? $d : "assets/img/user.png";
                        return "<img width=\"60\" src=\"$img\" alt=\"photo\"/>";
                    }),
                    array( 'db' => 'user', 'dt' => 1, 'formatter' => function($d, $row) {
                        $html = '<div  class="data_table_inner_menu">';
                            $html.= "<ul><li><a href=\"#\">$d</a><ul>";
                                $html.= "<li><a href=\"?module=users&action=employee&view=$d\">View & Edit</a></li>";
                            $html.= '</ul></li></ul>';
                        $html.= '</div>';
                        return $html;
                        // return $this->TABLE_INNER_MENU("?module=settings&action=users", $d, array("edit" => "Edit", "view" => "View"));
                    }),
                    array( 'db' => 'role',	 'dt' => 2 ),
                    array( 'db' => 'email',	 'dt' => 3 ),
                    array( 'db' => 'name',	 'dt' => 4 ),
                    array( 'db' => 'mobile', 'dt' => 5 ),
                    array( 'db' => 'publish','dt' => 6, 'formatter' => function($d, $row) {
                        $sts = array(0 => '<strong class="text-danger">Deactive</strong>', 1 => '<strong class="text-success">Active</strong>', 2 => '<strong class="text-warning">Pending</strong>');
                        return array_key_exists($d, $sts) ? $sts[$d] : $d;
                    }),
                    array( 'db' => 'created','dt' => 7, 'formatter' => function($d, $row) {
                        $dt = new DateTime($d, new DateTimezone('Asia/Dhaka'));
                        return $dt->format('jS M Y');
                    }),
                );
            }
    
            return $this->msg(0, $this->JSON_TABLE_DATA($request,$table,$primaryKey,$columns,$Where,$joinQuery,$groupBy,$having));
        }
        # Pages's Table
        public function PAGES_TABLE($request) {
            $table=$primaryKey=$columns=$Where=$joinQuery=$groupBy=$having='';

            if(isset($request['pages_tbl'])) {
                $columns = array(
                    array( 'db' => '`p`.`id`', 'dt' => 0, 'field' => 'id', 'formatter' => function($d, $row) {
                        return "<a href=\"?module=settings&action=pages&pedit=$d\" title=\"Edit\">#$d</a>";
                    }),
                    array( 'db' => '`p`.`pageTitle`', 'dt' => 1, 'field' => 'pageTitle'),
                    array( 'db' => '`m`.`title`',     'dt' => 2, 'field' => 'title' ),
                    array( 'db' => '`p`.`Author`',    'dt' => 3, 'field' => 'Author' ),
                    array( 'db' => '`p`.`publish`',   'dt' => 4, 'field' => 'publish', 'formatter' => function($d, $row) {
                        $active = array(0 => '<strong class="text-danger">Unpublish</strong>', 1 => '<strong class="text-success">Publish</strong>', 2 => '<strong class="text-warning">Pending</strong>');
                        return array_key_exists($d, $active) ? $active[$d] : $d;
                    }),
                    array( 'db' => '`p`.`created`',   'dt' => 5, 'field' => 'created', 'formatter' => function($d, $row) {
                        $dt = new DateTime($d, new DateTimezone('Asia/Dhaka'));
                        return $dt->format('jS M Y');
                    }),
                );

                $table = PREFIX."page"; $primaryKey= "id";
                $Where = "Author='".$_SESSION['user_inf']->user ."'";
                $joinQ = "FROM ".PREFIX."page AS p JOIN ".PREFIX."module AS m ON (p.module = m.id)";
            }
    
            return $this->msg(0, $this->JSON_TABLE_DATA($request,$table,$primaryKey,$columns,$Where,$joinQ,$groupBy,$having));
        }
    
        
        public function JSON_TABLE_DATA($request,$table,$primaryKey,$columns,$extraWhere='',$joinQuery='',$groupBy='',$having='') {
            $db = array('user' => _DBUSER_,'pass' => _DBPASS_, 'db' => _DBNAME_,'host' => _DBHOST_);
        
            require('plugins/ssp/ssp.php' );
            return SSP::simple($request,$db,$table,$primaryKey,$columns,$joinQuery,$extraWhere,$groupBy,$having);
        }

        public function TABLE_INNER_MENU($base, $id, $info) {
            $html = '<div  class="data_table_inner_menu">';
                $html.= "<ul><li><a href=\"#\">$d</a><ul><li>";
                    foreach($info as $k => $v) {
                        $html .= "<a href=\"$base&$k=$id\">$v</a>";
                    }
                $html.= '</li></ul></li></ul>';
            $html.= '</div>';

            return $html;
        }

        public function msg($status, $msg) {
            return json_encode(array("status" => "$status", "resp" => $msg));
        }
    }
?>