<?php

function gen_report($obj){
  $ret = '';
  foreach($obj as $row){
    $lst = count($row)-1;
    if(isset($row[0]->fieldset_start)){
      if(isset($row[0]->text_color))  $text_color=$row[0]->text_color; 
      else $text_color= '';
      $ret .="<fieldset class=\"well addr-fieldset\"><legend class=\"addr-legend\" ><label class=\"$text_color\">" . $row[0]->fieldset_start . "</label></legend>"; 
    }

    if(isset($row[0]->panel_start)){
      $prow = $row[0];
      $panel_class = isset($prow->panel_class) ? $prow->panel_class:'panel-default';
      $ret .= "<div class=\"panel $panel_class\">";
      if(isset($prow->panel_heading))  $ret .= "<div class=\"panel-heading\">$prow->panel_heading</div>";
      $ret .="<div class=\"panel-body\">";
      #$ret .= $prow->panel_body;
      
    }

    $ret .="<div class=\"row\">";
    foreach($row as $col){
       if(isset($col->class_label)){
         $ret .="<div class=\"$col->class_label\">\n";
           $ret .="<label>" . $col->label . "</label>";
         $ret .="</div>";
       }
       if(isset($col->value)){
         $ret .="<div class=\"$col->class_val  \">\n";
           $ret .="<label>" . $col->value . "</label>";
	 $ret .="</div>";
       }
       if(isset($col->height) && isset($col->width)){
         $height= $col->height;
         $width = $col->width;
	 $preview = $col->preview;
	 $ret .="<div class=\"form-group $col->class_val  \">";
           $ret .="<img height=\"$height\" width=\"$width\" src=\"$preview\" align=\"absmiddle\" style=\"border:1px solid green\" />";
         $ret .="</div>";
       }         
     }
     $ret .="</div>";
     if(isset($row[$lst]->fieldset_end)){
       $ret .="</fieldset>";
     }

   if(isset($row[$lst]->panel_end)){
      $ret .= "</div>";
      if(isset($row[$lst]->panel_footer)){
        $ret .="<div class=\"panel-footer\">";
          $ret .= $row[$lst]->panel_footer_cont;
        $ret .= "</div>";
      }
      $ret .= "</div>";
    }

 
  }
  return $ret;
}

function gen_table($obj,$table_id,$data_table = false) {
  $ret = '';
  $div_cls = ($data_table == true) ? "material-datatables" : "table-responsive";
  $ret .= "<div class=\"$div_cls\">";
  $ret .="<table class=\"table table-striped table-no-bordered table-hover\" id=\"$table_id\" cellspacing=\"0\" width=\"100%\" style=\"width:100%\">";
  $ret .= "<thead>";
  $ret .= "<tr>";

  foreach($obj as $row){
    foreach($row as $col){
      if(isset($col->label) && $col->label != '') {
        $id = isset($col->id) ? "id=\"$col->id\"":'';
        $class = isset($col->class) ? "class=\"$col->class\"" : '';
        $width = isset($col->width) ? "width=\"$col->width\"" : '';
        $ret .= "<th $id $class $width>$col->label</th>";
      }
    }
  }
  $ret .= "</tr>";
  $ret .= "</thead>";
  if($data_table == false) {
    $ret .= "<tbody>";
    $ret .= "<tr>";

    foreach($obj as $row){
      $lst = count($row)-1;
      foreach($row as $col){
        if(isset($col->value)){
          $id = isset($col->id) ? "id=\"$col->id\"":'';
          $class = isset($col->class) ? "class=\"$col->class\"" : '';
          $width = isset($col->width) ? "width=\"$col->width\"" : '';
          $ret .= "<td $id $class $width>$col->value</td>";
        }
      }
      $ret .= "</tr>";
    }
    $ret .= "</tbody>"; 
  }
  $ret .="</table>";
  $ret .="</div>";

  return $ret;
}


function gen_form($obj,$form_id,$form_action) {
  require_once("form_funcs.php");

  $ret ="<form role=\"form\" id=\"$form_id\" action=\"$form_action\" method=\"post\" enctype=\"multipart/form-data\">";
  $count = 0;
  foreach($obj as $row){
    $lst = count($row)-1;
    $count++;
    if (isset($row[0]->fieldset_start)) {
      #echo "<div id=\"field_" . $col->name . "\">"; 
      if(isset($row[0]->text_color))  $text_color=$row[0]->text_color; 
      else $text_color= '';
      $ret .="<fieldset class=\"well addr-fieldset\"><legend class=\"addr-legend\" ><label class=\"$text_color\">" . $row[0]->fieldset_start . "</label></legend>";
    }
    #$ret .="<div class=\"row\" id=\"col_" . (isset($col->name)?$col->name:'') . "\">";

    if(isset($row[0]->panel_start)){
      $prow = $row[0];
      $panel_class = isset($prow->panel_class) ? $prow->panel_class:'panel-default';
      $ret .= "<div class=\"panel $panel_class\">";
      if(isset($prow->panel_heading))  $ret .= "<div class=\"panel-heading\">$prow->panel_heading</div>";
      $ret .="<div class=\"panel-body\">";
      #$ret .= $prow->panel_body;
    }

    if(isset($row[0]->tab_start)){
      $ret .= "<ul class=\"nav nav-tabs\">"; 
      foreach($row[0]->tab_menu as $k=>$v){  
        $active = $v['class'];  
        $url = $v['url'];
        $label = $v['label'];
        $ret .= "<li class=\"$active\"><a data-toggle=\"tab\" href=\"#$url\">$label</a></li>";
      }
      $ret .= "</ul>";
    }

    if(isset($row[0]->tab_content)){
      if(isset($row[0]->tab_first))  $ret .= "<div class=\"tab-content\">";
      $active = isset($row[0]->tab_first)  ? 'active':'';
      $content_class = isset($row[0]->content_class) ? $row[0]->content_class:"tab_margin";
      $ret .= "<div class=\"tab-pane $active $content_class \" id=\"".$row[0]->tab_id ."\">";
    }

    if(isset($row[0]->div_start)){
      $disabled = (isset($row[0]->disabled) && $row[0]->disabled == true) ? "disabled=\"$disabled\"" : '';
      $ret .= "<div id=\"". $row[0]->id ."\" $disabled>";
    }

    $ret .="<div class=\"row\" id=\"col_" . $count . "\">";

    foreach($row as $col){
      $ret .="<div id=\"row_" . preg_replace("/[\[\]]+/", "", isset($col->name)?$col->name:'') . "\" " . (isset($col->sdisplay) ? "style=\"display: " . $col->sdisplay . "\"" : "") .  ">";
      if(isset($col->class_label)){
        $ret .="<div class=\"form-group " . $col->class_label . "\">\n";
          $ret .= "<label>" . $col->label . "</label>";
	      $ret .= "</div>";
      }
      if(isset($col->class_obj)){
        $ret .="<div class=\"form-group " . $col->class_obj . "\">\n";
          $ret .=gen_input($col);
        $ret .="</div>";
      }
      $ret .="</div>";
    }
    $ret .="</div>";
    if (isset($row[$lst]->fieldset_end)) {
      $ret .="</fieldset>";
      #echo "</div>";
    }
    
    if (isset($row[$lst]->div_end)){
      $ret .="</div>";
    }
   if(isset($row[$lst]->panel_end)){
      $ret .= "</div>";
      if(isset($row[$lst]->panel_footer)){
        $ret .="<div class=\"panel-footer\">";
          $ret .= $row[$lst]->panel_footer_cont;
        $ret .= "</div>";
      }
      $ret .= "</div>";
    }

    if(isset($row[$lst]->tab_end)){
      $ret .= "</div>";
      if(isset($row[$lst]->tab_lst))  $ret .="</div>";
    }


  }
  $ret .="</form>";
  return $ret;
}
	    

function gen_home_panel($obj){
  $ret = "<div class=\"row\">";

  foreach($obj as $rows){
    foreach($rows as $col){
      $panel_class = (isset($col->panel_class) && ($col->panel_class != ''))  ? $col->panel_class:'panel-default';
      $ret .= "<div class=\"$col->class\">";
      $ret .= "<div class=\"panel $panel_class\">";
      if(isset($col->title)){
        $ret .= "<div class=\"panel-heading text-center\"><a href=\"$col->url\"><strong>$col->title</strong></a></div>";
      }
      $ret .= "<div class=\"panel-body\">";
      if(isset($col->preview) && $col->preview != ''){
        $ret .= "<img src=\"$col->preview\"></img>";
      }
      $ret .= "</div>";
      $ret .= "</div>";
      $ret .= "</div>";
    }
  }
  $ret .= "</div>";
  return $ret;
}

?>
