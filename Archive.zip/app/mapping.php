<?php
    $user_status = [["value"=>0,"display"=>'Deactive'],["value"=>1,"display"=>'Active'], ["value"=>2,"display"=>'Pending']];

    $icons = file_get_contents("assets/json/icons.json");
?>