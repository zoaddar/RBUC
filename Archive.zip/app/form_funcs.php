<?php
	function gen_form($obj,$form_id, $action=FORM_ACTION) {
		$ret ="<form role=\"form\" id=\"$form_id\" action=\"$action\" method=\"post\" enctype=\"multipart/form-data\" novalidate=\"novalidate\">";
		$ret .= "<input type=\"hidden\" name=\"form_submit\" value=\"true\">";
		$count = 0;
		foreach($obj as $row){
			$lst = count($row)-1;
			$count++;

			$ret .="<div class=\"row\" id=\"col_" . $count . "\">";
			foreach($row as $col) {
				if($col->type == "hidden") { $ret .= gen_hidden($col); continue; }

				$col_obj = isset($col->col_obj) ? $col->col_obj : 'col-md-12';
				$id	     = preg_replace("/[\[\]]+/", "", isset($col->name) ? $col->name : '');
				$div_sty = isset($col->sdisplay) ? "style=\"display: " . $col->sdisplay . "'" : "";

				$ret .="<div id=\"row_". $id ."\" ". $div_sty." class=\"$col_obj\">";
					$ret .= gen_fields($col);
				$ret .="</div>";
			}
			$ret .="</div>";
		}
		$ret .="</form>";

		return $ret;
	}

	function gen_fields($col) {
		switch ($col->type) {
			case 'number': case 'password': case 'email': case 'text': case 'tel':
				$ret = call_user_func_array("gen_text", array($col));
			break;
 
			case 'submit': case 'button': case 'hidden': case 'tag': case 'modal':
				$return = array("hidden","tag","modal");
				$type = in_array($col->type, $return) ? $col->type : "button";
				return call_user_func_array("gen_".$type, array($col));
			break;

			case 'radio':
				$ret = call_user_func_array("gen_checkbox", array($col));
			break;

			default:
				$ret = call_user_func_array("gen_".$col->type, array($col));
			break;
		}

		$break 	 = ($col->type == "select") ?  "topbreak" : "";
		$col_obj = isset($col->col_obj) ? $col->col_obj : 'col-md-12';
		$id	     = preg_replace("/[\[\]]+/", "", isset($col->name) ? $col->name : '');
		$div_sty = isset($col->sdisplay) ? "style=\"display: " . $col->sdisplay . "'" : "";

		$comp ="<div id=\"row_". $id ."\" ". $div_sty." class=\"$col_obj $break\">";
			$comp .= $ret;
		$comp .="</div>";

		return $comp;
	}

	function gen_textarea($obj) {
		$type 		 = $obj->type;
		$name   	 = isset($obj->name) ? $obj->name."[".$obj->title."]" : 'name';
		$value 		 = isset($obj->value) ? $obj->value : "";
		$id   		 = isset($obj->id) ? $obj->id : $name;
		$rows		 = isset($obj->rows) ? "rows=" . $obj->rows : "";
		$disabled 	 = (isset($obj->disabled) && $obj->disabled) ? "disabled" : "";
		$required 	 = (isset($obj->required)) ? $obj->required : "";
		$placeholder = (isset($obj->placeholder) ? $obj->placeholder : "");

		$ret  = "<div class=\"form-group\">\n";
			$ret .= "<label class=\"bmd-label-floating\" for=\"$id\">".$obj->title."</label>\n";
			$ret .= "<textarea class=\"form-control\" type=\"$type\" name=\"$name\" placeholder=\"$placeholder\" id=\"$id\" $rows autofocus $required $disabled>$value</textarea>";
		$ret .= "</div>";
			
		return $ret;
	}

	function gen_text($obj) {
		$type 	      = $obj->type;
		$name   	  = isset($obj->name) ? "name='".$obj->name."[".$obj->title."]"."'" : '';
		$value   	  = isset($obj->value) ? "value='".$obj->value."'" : "";
		$id   	      = isset($obj->id) ? $obj->id : md5(uniqid(rand(), true));
		$class 	      = isset($obj->class) ? $obj->class : "";
		$disabled     = isset($obj->disabled) ? $obj->disabled : "";
		$readonly     = isset($obj->readonly) ? $obj->readonly : "";
		$step 	      = isset($obj->step) ? "step='".$obj->step."'" : "";
		$max 	      = isset($obj->max) ? "max='".$obj->max."'" : "";
		$min 	      = isset($obj->min) ? "min='".$obj->min."'" : "";
		$maxLength    = isset($obj->maxLength) ? "maxLength='".$obj->maxLength."'" : "";
		$minLength    = isset($obj->minLength) ? "minLength='".$obj->minLength."'" : "";
		$range 	      = isset($obj->range) ? "range='".$obj->range."'" : "";
		$autofocus	  = (isset($obj->autofocus) && $obj->autofocus) ? "autofocus" : "";
		$required	  = (isset($obj->required) && $obj->required) ? "required" : "";
		$placeholder  = isset($obj->placeholder) ? $obj->placeholder : "";
		$autocomplete = isset($obj->autocomplete) ? "autocomplete='".$obj->autocomplete."'" : "";
		$pattern 	  = isset($obj->pattern) ? "pattern='".$obj->pattern."'" : "";
		$equalTo 	  = isset($obj->equalTo) ? "equalTo='#".$obj->equalTo."'" : "";
		$label_class  = isset($obj->label_class) ? $obj->label_class : "bmd-label-floating";

		$ret = "";
		if(isset($obj->title)) {
			$ret .= "<div class=\"form-group\">\n";
			$ret .= "<label class=\"$label_class\" for=\"$id\">".$obj->title."</label>\n";
		}
		$ret .= "<input class=\"form-control $class\" type=\"$type\" $name placeholder=\"$placeholder\" id=\"$id\" $value $equalTo $pattern $autofocus $required $disabled $readonly $max $maxLength $min $minLength $range $step $autocomplete />";
		if(isset($obj->title)) $ret .= "</div>";

		return $ret;
	}

	function gen_checkbox($obj) {
		$type   = $obj->type;
		$span   = ($type == "radio") ? "circle" : "form-check-sign";
		$name   = isset($obj->name) ? $obj->name."[]" : $obj->name;
		$title  = $obj->title;
		$Kseach = isset($obj->checked) ? $obj->checked : '';
		$id     = isset($obj->id) ? $obj->id : $obj->name;
		$class  = isset($obj->class) ? $obj->class : 'mr-auto';
		$values = isset($obj->value) ? json_decode($obj->value, true) : '';

		$ret=$value=""; $i=0; $val_arr = array();

		$ret .= "<div class=\"row\">\n";
			$ret.= "<label class='".$obj->title_class."'>".$obj->title."</label>";
			$ret .= "<div class='".$obj->title_col."'>\n";
			foreach ($values as $opt) {
				$id       = $id."_".$i;
				$value 	  = $opt['value'];
				$display  = $opt['display'];
				$checked  = (isset($opt['checked']) || $Kseach == $value) ? 'checked' : '';
				$required = isset($opt['required']) ? 'required' : '';
				$disabled = isset($opt['disabled']) ? 'disabled' : '';
				$encoded  = base64_encode(json_encode(["title"=>$title, "display"=>$display, "value"=>$value]));
				
				$ret .= "<div class=\"form-check $class $disabled\"><label class=\"form-check-label\"><input type=\"$type\" id=\"$id\" class=\"form-check-input\" name=\"$name\" value=\"$encoded\" $checked $required $disabled> $display<span class=\"$span\"><span class=\"check\"></span></span></label></div>";
			}
			$ret .= "</div>";
		$ret .= "</div>";
		
		return $ret;
	}
	
	function gen_button($obj) {
		$type 	  = isset($obj->type) ? $obj->type : "";
		$name 	  = isset($obj->name) ? $obj->name : "";
		$id 	  = isset($obj->id) ? $obj->id : $name;
		$class    = isset($obj->class) ? $obj->class : "btn-fill btn-rose";
		$value	  = isset($obj->value) ? $obj->value : "Save";
		$disabled = (isset($obj->disabled) && $obj->disabled == true) ? "disabled" : ""; 
		$onclick  = isset($obj->onclick) ? "onclick=\"". $obj->onclick ."\"" : "";

		return "<button class=\"btn $class\" type=\"$type\" name=\"$name\" $disabled  id=\"$id\" $onclick>$value</button>";
	}
	
	function gen_submit($obj) {
		$type 	  = isset($obj->type) ? $obj->type : "";
		$name 	  = isset($obj->name) ? $obj->name : "";
		$id 	  = isset($obj->id) ? $obj->id : $name;
		$class    = isset($obj->class) ? $obj->class : "btn-fill btn-rose";
		$value	  = isset($obj->value) ? $obj->value : "Save";
		$disabled = (isset($obj->disabled) && $obj->disabled == true) ? "disabled" : "";
		$onclick  = isset($obj->onclick) ? "onclick=\"". $obj->onclick ."\"" : "";

		return "<button class=\"btn $class\" type=\"$type\" name=\"$name\" $disabled  id=\"$id\" $onclick>$value</button>";
	}


	function gen_select($obj) {
		$type   	= $obj->type;
		$required 	= isset($obj->required) ? $obj->required : '';
		$multiple   = isset($obj->multiple) ? 'multiple' : '';
		$title  	= isset($obj->title) ? $obj->title : 'Title';
		$name   	= isset($obj->name) ? $obj->name."[]" : $obj->name;
		$id     	= isset($obj->id) ? $obj->id : $obj->name;
		$key_search = isset($obj->selected) ? $obj->selected : '';
		$class  	= isset($obj->class) ? $obj->class : '';
		$data_size  = isset($obj->data_size) ? $obj->data_size : '7';
		$data_style = isset($obj->data_style) ? $obj->data_style : 'btn btn-primary btn-round';
		$values 	= isset($obj->value) ? json_decode($obj->value, true) : '';
		$event 		= isset($obj->event) ? $obj->event : "";

		$ret = "<select id=\"$id\" name=\"$name\" $multiple data-size=\"$data_size\" data-style=\"$data_style\" class=\"$class\" searchable=\"search\" $event $required>";
		$ret .= "<option disabled selected>$title</option>";
		if (isset($values) && is_array($values)) {
			$value="";
			foreach ($values as $opt) {
				if (!isset($opt['value']) || $opt['value'] === "") continue;
				$value 	  = $opt['value'];
				$display  = $opt['display'];
				$selected = (isset($opt['selected']) && $opt['selected'] == true) || ($value==$key_search) ? "selected" : "";
				$encoded  = base64_encode(json_encode(["title"=>$title, "display"=>$display, "value"=>$value]));

				$ret.="<option value=\"$encoded\" $selected>$display</option>";
			}
		}
		$ret .= "</select>";

		return $ret;
	}

	function gen_hidden($obj) {
		$type 	  = $obj->type;
		$title 	  = isset($obj->title) ? $obj->title : "";
		$name     = isset($obj->name) ? $obj->name."[".$title."]" : $obj->name."[hidden_data]";
		$id   	  = isset($obj->id) ? $obj->id : "id";
		$class 	  = isset($obj->class) ? $obj->class : "";
		$required = (isset($obj->required) && $obj->required == false) ? "" : "required";
		$value 	  = isset($obj->value) ? $obj->value : "";

		return "<input class=\"$class\" type=\"$type\" name=\"$name\" value=\"$value\" id=\"$id\" $required>";
	}

	function gen_img($obj) {
		$name	   = isset($obj->name) ? $obj->name : "...";
		$class	   = isset($obj->class) ? $obj->class : "";
		$circle	   = isset($obj->circle) ? "img-circle" : "";
		$width     = isset($obj->width) ? "style=\"max-width:". $obj->width .";\"" : "";
		$selectbtn = isset($obj->selectbtn) ? $obj->selectbtn : "btn-rose btn-round";
		$removebtn = isset($obj->removebtn) ? $obj->removebtn : "btn-danger btn-round";
		$exist_img = !empty($obj->exist_img) ? $obj->exist_img : "assets/img/image_placeholder.jpg";

		$html = "<div class=\"fileinput fileinput-new text-center $class\" data-provides=\"fileinput\">";
			$html.= "<div class=\"fileinput-new thumbnail $circle\" $width>";
				$html.= "<img src=\"$exist_img\" alt=\"...\">";
			$html.= "</div>";
			$html.= "<div class=\"fileinput-preview fileinput-exists thumbnail $circle\"></div>";
			$html.= "<div>";
				$html.= "<span class=\"btn $selectbtn btn-file\">";
					$html.= "<span class=\"fileinput-new\">Select image</span>";
					$html.= "<span class=\"fileinput-exists\">Change</span>";
					$html.= "<input type=\"file\" name=\"$name\" id=\"$name\" />";
				$html.= "</span>";
				$html.= "<a href=\"#\" class=\"btn $removebtn fileinput-exists\" data-dismiss=\"fileinput\"><i class=\"fa fa-times\"></i> Remove</a>";
			$html.= "</div>";
		$html.= "</div>";

		return $html;
	}

	function gen_preview($obj){
	  $type=$obj->type;
	  $name=$obj->name;
	  $id=$name;
	  $height=$obj->height;
	  $width=$obj->width;
	  $preview=$obj->preview;
	  $preview_img=$obj->preview_img;
	  $image_exists = file_exists($preview_img);
	  if (isset($obj->required) && $obj->required == false) $required = ""; else $required="required";

	  $ret="<div class=\"form-group\">"; 
	  #$ret .= "<img height=\"$height\" width=\"$width\" ". ($is_image_exists == 0 ?  'required' : " style=\"visibility:hidden;\" "  ) ." align=\"absmiddle\" id=\"$preview\" src=\"\" style=\"border:2px solid green\"/>";
	  $ret .= "<img height=\"$height\" width=\"$width\" align=\"absmiddle\" id=\"$preview\" src=\"$preview_img\" style=\"border:1px solid green\"/>";
	  $ret .="</div>";
	  $ret .="<input type=\"file\"  name=\"$name\" id=\"$name\" " . (!$image_exists? "$required" : "") . " onchange=\"PreviewImage('$name','$preview');\">";  
	  
	  return $ret;
	}

	function gen_toggle($obj) {
	  $type = "checkbox";
	  $name = $obj->name;
	  $value = '0';
	  $class = "checkbox-inline";
	  $hidden_name = $obj->hidden_name;
	  $id = isset($obj->id)? $obj->id:$name;
	  $obj_class = isset($obj->class)? $obj->class : '';
	  $ret .= "<label class=\"$class\"><input type=\"$type\" id = \"$id\" class=\"$obj_class\" name=\"$name\" value=\"$value\" ></label>";
	  $ret .="<input type=\"hidden\" name=\"$hidden_name\" id= \"hidden_1\" class=\"$class\" value=\"$value\">";
	  
	  return $ret;
	}

	function gen_tag($obj) {
		$html ="";
		$id   	 = isset($obj->id) ? " id='".$obj->id."'" : "";
		$class   = isset($obj->class) ? " class='".$obj->class."'" : "";
		$href 	 = isset($obj->href) ? " href='".$obj->href."'" : "";
		$src 	 = isset($obj->src) ? " src='".$obj->src."'" : "";
		$action  = isset($obj->action) ? " action='".$obj->action."'" : "";
		$content = isset($obj->content) ? $obj->content : "";
		$tag_end = isset($obj->end) ? "</".$obj->label.">" : "";

		$html .= "<".$obj->label . $action . $src . $href . $id . $class .">".$content .$tag_end;

		return $html;
	}

	function menuBuilder($menu_array, $is_sub=FALSE) {
		$menu = "<ul class='nav'>";

		foreach ($menu_array as $parent => $sub) {
			$icons  = isset($sub['icons']) ? $sub['icons'] : '';
			$href   = isset($sub['href'])  ? $sub['href'] : '';
			$mini   = isset($sub['mini'])  ? $sub['mini'] : '';
			$normal = isset($sub['normal'])  ? $sub['normal'] : '';
			$sub_m  = (isset($sub['s_item']) && count($sub['s_item']) > 0) ? true : false;
			$module = isset($_REQUEST['module']) ? $_REQUEST['module'] : 'home';
			$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : 'home';

			$active = (strpos($href, "#".$module) !== false || strpos($href,$action) !== false)?"active":'';
			$show   = ($active != '') ? "show" : "";

			$m_m = "<i class=\"material-icons\">$icons</i>";
			$m_m.= ($sub_m) ? "<p> $parent <b class=\"caret\"></b> </p>" : "<p> $parent </p>";
			$s_m = "<span class=\"sidebar-mini\"> $mini </span>";
			$s_m.= "<span class=\"sidebar-normal\"> $normal </span>";

			$extra = (!$is_sub) ? $m_m : $s_m;
			$dropdown = ($sub_m) ? "data-toggle=\"collapse\" aria-expanded=\"true\"" : "";

			$menu .= "<li class=\"nav-item $active\">";
				$menu .= "<a class=\"nav-link\" href=\"$href\" $dropdown>$extra</a>";
				if($sub_m) {
					foreach ($sub as $v) {
						if(is_array($v)) {
							$menu .= "<div class=\"collapse $show\" id='".str_replace('#','',$href)."'>";
								$menu .= menuBuilder($v, TRUE);
							$menu .= "</div>";
						}
					}
				}
			$menu .= "</li>";
		}
		return $menu . "</ul>";
	}

	function gen_table($obj, $table_id="", $data_table = false) {
		$div_cls = ($data_table == true) ? "table-responsive" : "table-responsive";
		$thd_cls = isset($obj[0][0]->thd_cls) ? $obj[0][0]->thd_cls : "card-header-rose text-white";

		$ret  = "<div class=\"$div_cls\">";
		$ret .= "<table class=\"table table-striped table-no-bordered table-hover\" id=\"$table_id\" cellspacing=\"0\" width=\"100%\" style=\"width:100%\">";
		$ret .= "<thead class=\"$thd_cls\">";
		$ret .= "<tr>";

		foreach($obj as $row){
			foreach($row as $col){
				if(isset($col->label) && $col->label != '') {
					$colspan = isset($col->colspan) ? "colspan=\"$col->colspan\"" : '';
					$class = isset($col->class) ? "style=\"$col->class\"" : '';
					$width = isset($col->width) ? "width=\"$col->width\"" : '';
					$ret .= "<th $colspan $class $width>$col->label</th>";
				}
			}
		}
		$ret .= "</tr>";
		$ret .= "</thead>";

		if($data_table == false) {
			$ret .= "<tbody>";
			$ret .= "<tr>";

			foreach($obj as $row){
				$lst = count($row)-1;
				foreach($row as $col){
					if(isset($col)){
						$id    = isset($col->id) ? "id=\"$col->id\"" : '';
						$class = isset($col->class) ? "class=\"$col->class\"" : '';
						$width = isset($col->width) ? "width=\"$col->width\"" : '';
						$value = isset($col->value) ? $col->value : '';

						$ret .= "<td $id $class $width>$value</td>";
					}
				}
				$ret .= "</tr>";
			}
			$ret .= "</tbody>"; 
		}
		$ret .="</table>";
		$ret .="</div>";

		return $ret;
	}

	function gen_card($row) {
		$ret ="";
		# card start
		if (isset($row->card_start) && $row->card_start) {
			$card_color = isset($row->card_color) ? $row->card_color : 'rose';
			$card_head  = isset($row->card_icon)  ? "icon" : 'text';
			$card_title = isset($row->card_title) ? $row->card_title : 'Form';
			$card_class = isset($row->card_class) ? $row->card_class : 'card';

			$ret .= "<div class=\"$card_class\">";
			# Avatar
			if(isset($row->avatar)) {
				$ret .= "<div class=\"card-avatar\">";
					$ret .= "<img class=\"img\" src=".$row->avatar." />";
				$ret .= "</div>";
			}
			else {
				$ret .= "<div class=\"card-header card-header-$card_color card-header-$card_head\">";
				$ret .= "<div class=\"card-$card_head\">";
				if(isset($row->card_icon)) {
					$ret .= "<i class=\"material-icons\">".$row->card_icon."</i>";
					$ret .= "</div>";
				}
				$ret .= "<h4 class=\"card-title\">$card_title</h4>";
				$ret .= !isset($row->card_icon) ? "</div>" : "";
				$ret .= "</div>";
			}
			$ret .= "<div class=\"card-body\">";
		}
		# card end
		if (isset($row->card_end) && $row->card_end) {
			# toolbar
			if(isset($row->toolbar)) {
				$ret .= "<div class=\"toolbar\">";
					$count = 0;
					foreach($row->toolbar as $contents) {
						$count++;
						$ret .="<div class=\"text-center\" id=\"col_" . $count . "\">";
							foreach($contents as $content) {
								$ret .= gen_fields($content);
							}
						$ret .="</div>";
					}
				$ret .= "</div>";
			}
			# Form
			if(isset($row->form)) {
				$event = isset($row->event) ? $row->event : "";
				$ret.= "<form role=\"form\" id='".$row->form[0]."' action='".$row->form[1]."' method=\"post\" enctype=\"multipart/form-data\" novalidate=\"novalidate\" $event>";
				$ret.= "<input type=\"hidden\" name=\"form_submit\" value=\"true\">";
			}
			if(isset($row->table)) {
				$ret.= call_user_func_array("gen_table", $row->table);
			}
			# body
			if(isset($row->card_body)) {
				$count = 0;
				foreach($row->card_body as $contents) {
					$count++;
					$ret .="<div class=\"row\" id=\"col_" . $count . "\">";
						foreach($contents as $content) {
							$ret .= gen_fields($content);
						}
					$ret .="</div>";
				}
			}
			# footer
			if(isset($row->card_footer_content)) {
				$count = 0;
				$class = isset($row->card_footer_class) ? $row->card_footer_class : "";
				$ret .="<div class=\"card-footer $class\">";
					foreach($row->card_footer_content as $contents) {
						$count++;
						$ret .="<div class=\"row\" id=\"col_" . $count . "\">";
							foreach($contents as $content) {
								$ret .= gen_fields($content);
							}
						$ret .="</div>";
					}
				$ret .="</div>";
			}
			$ret .= (isset($row->form)) ? "</form>" : "";

			$ret .="</div></div>";
		}
		return $ret;
	}

	function gen_modal($obj) {
		$btn_class  = isset($obj->btn_class) ? $obj->btn_class : "btn-primary";
		$btn_value  = isset($obj->btn_value) ? $obj->btn_value : "Modal";
		$modal_id   = isset($obj->id) ? $obj->id : "exampleModal";
		$modal_cls  = isset($obj->class) ? $obj->class : "";
		$modal_size = isset($obj->modal_size) ? $obj->modal_size : "";
		$title 	    = isset($obj->title) ? $obj->title : "Title";
		$footer_cls = isset($obj->footer_class) ? $obj->footer_class : "";

		$html = "<button type=\"button\" class=\"btn $btn_class\" data-toggle=\"modal\" data-target=\"#$modal_id\">$btn_value</button>";

		$html.= "<div class=\"modal fade $modal_cls\" id=\"$modal_id\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"ModalLabel\" aria-hidden=\"true\">";
			$html.= "<div class=\"modal-dialog $modal_size\" role=\"document\">";
				$html.= "<div class=\"modal-content\">";
					$html.= "<div class=\"modal-header\">";
						$html.= "<h5 class=\"modal-title text-warning\" id=\"ModalLabel\">$title</h5>";
						$html.= "<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\">";
							$html.= "<span aria-hidden=\"true\">&times;</span>";
						$html.= "</button>";
					$html.= "</div>";
					# Form Start
					if(isset($obj->form)) {
						$event = isset($obj->event) ? $obj->event : "";
						$html.= "<form role=\"form\" id='".$obj->form[0]."' action='".$obj->form[1]."' method=\"post\" enctype=\"multipart/form-data\" novalidate=\"novalidate\" $event>";
						$html.= "<input type=\"hidden\" name=\"form_submit\" value=\"true\">";
					}
					# body
					$html.= "<div class=\"modal-body\">";
					if(isset($obj->body)) {
						$count = 0;
						foreach($obj->body as $contents) {
							$count++;
							$html .="<div class=\"row\" id=\"col_" . $count . "\">";
								foreach($contents as $content) {
									$html .= gen_fields($content);
								}
							$html .="</div>";
						}
					}
					$html.= "</div>";
					# body end
					if(isset($obj->form)) {
						$form_btn_cls = isset($obj->form_btn_class) ? $obj->form_btn_class : "btn-primary";
						$form_btn_val = isset($obj->form_btn_value) ? $obj->form_btn_value : "Save changes";
						$html.= "<div class=\"modal-footer $footer_cls\">";
							$html.= "<button type=\"submit\" class=\"btn $form_btn_cls\">$form_btn_val</button>";
						$html.= "</div></form>";
					}
					# Form End

				$html.= "</div>";
			$html.= "</div>";
		$html.= "</div>";
	  
	  return $html;
	}
?>