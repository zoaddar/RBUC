<?php
function read_csv($file) {
    $row = 0;
    $res = array();
    if (($handle = fopen($file, "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $row++;
            if($row == 1) continue;
            $res[] = array("eiin" => $data[1], "user_id" => $data[4], "marks" => $data[5]);
        }
        fclose($handle);
    }
    return $res;
}

?>

<html lang="en">
<head>
  <meta charset="utf-8">
  <title>clone demo</title>
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
 
<div class="control-group">
    <label for="select-beast">Beast:</label>
    <select id="select-beast" class="demo-default" placeholder="Select a person...">
        <option value="">Select a person...</option>
        <option value="4">Thomas Edison</option>
        <option value="1">Nikola</option>
        <option value="3">Nikola Tesla</option>
        <option value="5">Arnold Schwarzenegger</option>
    </select>
</div>
 
<table>
    <tbody>
        <tr>
            <td id="clone"></td>
        </tr>
    </tbody>
</table>

<script>
$( "#select-beast" ).clone().prependTo( "#clone" );
</script>
 
</body>
</html>