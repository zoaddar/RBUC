<?php
if(isset($_REQUEST)) {
    require("../app/functions.php");
    $func = new Functions();

    if(isset($_REQUEST['action']) && $_REQUEST['action']=="get") {
        // get full profile { action=get&user=root&pass=12345&domain=kader.nixtecsys.com }
        if(isset($_REQUEST['user']) && $_REQUEST['user'] != "" && isset($_REQUEST['pass']) && $_REQUEST['pass'] != "") {
            $_REQUEST['pass'] = md5($_REQUEST['pass']);
            $data = base64_encode(serialize($_REQUEST));
            $result = $func->GET_PROFILE($data, true);
        
            echo "<pre>";
            print_r($result);
        }
    }

    else if(isset($_REQUEST['action']) && $_REQUEST['action']=="add") {
        // User Create { action=add&auth=cm9vdC04MjdjY2IwZWVhOGE3MDZjNGMzNGExNjg5MWY4NGU3Yg==&user=someuser&pass=somepass&role=somerole }
        if(isset($_REQUEST['auth']) && $_REQUEST['auth'] != "" && isset($_REQUEST['user']) && $_REQUEST['user'] != "" && isset($_REQUEST['pass']) && $_REQUEST['pass'] != "" && isset($_REQUEST['role']) && $_REQUEST['role'] != "") {
            $data = base64_encode(serialize($_REQUEST));
            $result = $func->ADD_USER($data);
            // echo base64_encode("root-827ccb0eea8a706c4c34a16891f84e7b");
            echo "<pre>";
            print_r($result);
        }
    }

    else if(isset($_REQUEST['action']) && $_REQUEST['action']=="set") {
        // set additional option { action=set&auth=cm9vdC04MjdjY2IwZWVhOGE3MDZjNGMzNGExNjg5MWY4NGU3Yg==&user=someuser&xkey=domain&xval=kader.nixtecsys.com }
        if(isset($_REQUEST['auth']) && $_REQUEST['auth'] != "" && isset($_REQUEST['user']) && $_REQUEST['user'] != "" && isset($_REQUEST['xkey']) && $_REQUEST['xkey'] != "" && isset($_REQUEST['xval']) && $_REQUEST['xval'] != "") {
            $data = base64_encode(serialize($_REQUEST));
            $result = $func->SET_ADDITIONAL($data);

            echo "<pre>";
            print_r($result);
        }
    }

    else if(isset($_REQUEST['action']) && $_REQUEST['action']=="del") {
        // delete additional option { action=del&auth=cm9vdC04MjdjY2IwZWVhOGE3MDZjNGMzNGExNjg5MWY4NGU3Yg==&user=someuser&xkey=domain }
        if(isset($_REQUEST['auth']) && $_REQUEST['auth'] != "" && isset($_REQUEST['user']) && $_REQUEST['user'] != "" && isset($_REQUEST['xkey']) && $_REQUEST['xkey'] != "") {
            $data = base64_encode(serialize($_REQUEST));
            $result = $func->DEL_ADDITIONAL($data);

            echo "<pre>";
            print_r($result);
        }
    }

    else if(isset($_REQUEST['action']) && $_REQUEST['action']=="chp") {
        // change pass { action=chp&user=admin&pass=12345&newpass=123456 }
        if(isset($_REQUEST['user']) && $_REQUEST['user'] != "" && isset($_REQUEST['pass']) && $_REQUEST['pass'] != "" && isset($_REQUEST['newpass']) && $_REQUEST['newpass'] != "") {
            $_REQUEST['pass'] = md5($_REQUEST['pass']);
            $data = base64_encode(serialize($_REQUEST));
            $result = $func->CHANGE_PASS($data);

            echo "<pre>";
            print_r($result);
        }
    }

}
else {
    die($func->msg(10, "Parameters are required"));
}
?>
