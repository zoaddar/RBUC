<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="_KEYWORD_">
    <meta name="description" content="_DESCRIPTION_">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href="<?php echo _BASE_;?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo _BASE_;?>assets/css/idangerous.swiper.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo _BASE_;?>assets/css/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo _BASE_;?>assets/css/animate.css" rel="stylesheet" type="text/css" />
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo _FAVICON_; ?>">
    <title>_TITLE_</title>
</head>
_CUSTOM_CSS_
<body id="themeChange" class="header-floated">
    <!-- LOADER -->
    <div id="loader-wrapper">
        <div class="loader-content">
            <div class="circle1"></div>
            <div class="circle2"></div>
            <div class="title">Loading</div>
        </div>
    </div>
    <!-- HEADER -->
    <header>
            <div class="container">
                <div id="logo-wrapper">
                    <div class="cell-view"><a id="logo" href="index.php"><img src="<?php echo _BASE_;?>assets/img/logo.png" alt="" /></a></div>
                </div>
                <div class="open-icon">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="header-container">
                    <div class="scrollable-container">
                        <div class="header-left">
                            <nav>
                                <div class="menu-entry active">
                                    <a href="index.php">Home</a>
                                </div>
                                <div class="menu-entry">
                                    <a href="hosting.html">Hosting</a>
                                    <span class="submenu-icon"><span class="glyphicon glyphicon-chevron-down"></span></span>
                                    <div class="submenu">
                                        <div>
                                            <a href="hosting.html">Hosting</a>
                                            <a href="host-shared.html">Shared</a>
                                            <a href="host-vps.html">VPS</a>
                                            <a href="host-dedicated.html">Dedicated</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="menu-entry">
                                    <a href="host-domains.html">Domains</a>
                                </div>
                                <div class="menu-entry">
                                    <a href="#">Pages</a>
                                    <span class="submenu-icon"><span class="glyphicon glyphicon-chevron-down"></span></span>
                                    <div class="submenu">
                                        <div>
                                            <a href="host-about.html">About</a>
                                            <a href="host-faq.html">FAQ</a>
                                            <a href="host-testimonials.html">Testimonials</a>
                                            <a href="host-datacenters.html">Datacenters</a>
                                            <a href="host-support.html">Support</a>
                                            <a href="login-register.html">Login/Register</a>
                                            <a href="typography.html">Typography</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="menu-entry">
                                    <a href="blog.html">Blog</a>
                                    <span class="submenu-icon"><span class="glyphicon glyphicon-chevron-down"></span></span>
                                    <div class="submenu">
                                        <div>
                                            <a href="blog.html">Style 1</a>
                                            <a href="blog-1.html">Style 2</a>
                                            <a href="blog-detail.html">Blog Detail</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="menu-entry">
                                    <a href="contact.html">Contact us</a>
                                </div>
                                                                                    
                            </nav>
                        </div>
                        <div class="header-right">
                            <div class="header-inline-entry">
                                <div><span class="glyphicon glyphicon-time"></span><b>24/7</b> Customer Support </div>
                                <div><span class="glyphicon glyphicon-phone"></span><a href="tel:+485558753005" class="telephone-link">+48 555 8753 005</a></div>
                            </div>
                            <div class="header-inline-entry">
                                <a class="button" href="login-register.html">login</a>
                            </div>
                            <div class="header-inline-entry">
                                <a class="link" href="login-register.html">Register</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    
        <div class="subheader">
            <div class="container-fluid">
                <a id="subheader-logo" href="index-2.html"><img src="<?php echo _BASE_;?>assets/img/logo.png" alt="" /></a>
                <div class="subheader-content">
                    <div class="subheader-left">
                        <a class="scroll-to-link subheader-link" data-rel="1">Our Services</a>
                        <a class="scroll-to-link subheader-link" data-rel="2">Our Hosting</a>
                        <a class="scroll-to-link subheader-link" data-rel="3">Why Choose Us</a>
                        <a class="scroll-to-link subheader-link" data-rel="4">Which hosting is better</a>
                        <a class="scroll-to-link subheader-link" data-rel="5">Guarantee</a>
                    </div>
                    <div class="subheader-right">
                        <a class="button">Get Started</a>  
                    </div>
                </div>
            </div>
        </div>