<?php if(!$_SESSION['loggedin'] || $_SESSION['loggedin']!=true) header('location: login.php'); ?>

<div class="sidebar" data-color="<?php echo $sidebar_filter;?>" data-background-color="<?php echo $sidebar_bg; ?>" data-image="<?php echo $sidebarImgOpt; ?>">
  <div class="logo">
    <a href="?module=home&action=home" class="photo logo-mini">
      <img style="width:50px;" src="<?php echo $favicon;?>"/>
    </a>
    <a href="?module=home&action=home" class="simple-text logo-normal"><?php echo $company;?></a>
  </div>
  <div class="sidebar-wrapper">
    <div class="user">
      <div class="photo">
        <img src="<?php echo $userImg;?>" onerror="this.onerror=null;this.src='assets/img/user.png';" />
      </div>
      <div class="user-info">
        <a href="?module=home&action=profile" class="username">
          <span><?php echo strtoupper($user);?></span>
        </a>
      </div>
    </div>
    <?php echo menuBuilder($sidebarmenu, $is_sub = FALSE); ?>
  </div>
</div>