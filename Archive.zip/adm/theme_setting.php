<?php if(!$_SESSION['loggedin'] || $_SESSION['loggedin']!=true) header('location: login.php'); ?>

<div class="fixed-plugin">
  <div class="dropdown show-dropdown">
    <a href="#" data-toggle="dropdown">
      <i class="fa fa-cog fa-2x"> </i>
    </a>
    <ul class="dropdown-menu">
      <li class="header-title"> Theme</li>
      <li class="adjustments-line">
        <a href="javascript:void(0)" class="switch-trigger active-color">
          <div class="badge-colors ml-auto mr-auto">
            <?php
              foreach ($sidebar_filter_arr as $color) {
                echo '<span onclick=\'sidebar("sidebarFilter", "'.$color.'");\' ';
                echo 'class="badge filter badge-'.$color;
                echo ($activeThemeOptions->sidebarFilter == $color) ? ' active' : '';
                echo '" data-color="'.$color.'"></span>';
              }
            ?>
          </div>
          <div class="clearfix"></div>
        </a>
      </li>
      <li class="header-title">Sidebar Background</li>
      <li class="adjustments-line">
        <a href="javascript:void(0)" class="switch-trigger background-color">
          <div class="ml-auto mr-auto">
            <?php
              foreach ($sidebar_bg_arr as $bg) {
                echo '<span onclick=\'sidebar("sidebarBG", "'.$bg.'");\' ';
                echo 'class="badge filter badge-'.$bg;
                echo ($activeThemeOptions->sidebarBG == $bg) ? ' active' : '';
                echo '" data-background-color="'.$bg.'"></span>';
              }
            ?>
          </div>
          <div class="clearfix"></div>
        </a>
      </li>
      <li class="adjustments-line">
        <a href="javascript:void(0)" class="switch-trigger">
          <p>Sidebar Mini</p>
          <label class="ml-auto">
            <div class="togglebutton switch-sidebar-mini">
              <label>
                <input type="checkbox" id="sidebarMini" <?php echo ($sidebarMini!='' ) ? 'checked=""' : '';?>>
                <span class="toggle"></span>
              </label>
            </div>
          </label>
          <div class="clearfix"></div>
        </a>
      </li>
      <li class="adjustments-line">
        <a href="javascript:void(0)" class="switch-trigger">
          <p>Sidebar Images</p>
          <label class="switch-mini ml-auto">
            <div class="togglebutton switch-sidebar-image">
              <label>
                <input type="checkbox" id="sidebarImgOpt" <?php echo ($activeThemeOptions->sidebarImgOpt==1 ) ? 'checked=""' : '';?>>
                <span class="toggle"></span>
              </label>
            </div>
          </label>
          <div class="clearfix"></div>
        </a>
      </li>
      <li class="header-title">Images</li>
      
      <?php
        foreach ($sidebar_img_arr as $img) {
          echo '<li '; echo ($activeThemeOptions->sidebarImg == $img) ? 'class="active"' : '';
            echo '><a onclick=\'sidebar("sidebarImg", "'.$img.'");\' class="img-holder switch-trigger" href="javascript:void(0)">';
          echo '<img src="'.$img.'" alt=""/></a></li>';
        }
        
        if($_SESSION['user_inf']->role == 'root') {
          echo '<li style="height: 11px !important;" class="adjustments-line">';
          echo '<li class="header-title">UI Themes</li>';
          $func->ThemeOptions("uitheme");
        }
      ?>
    </ul>
  </div>
</div>