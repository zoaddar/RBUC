<?php require('header.php');?>

<body class="<?php echo $sidebarMini;?>">
    <div class="wrapper ">
        <?php require('sidebar.php');?>
        <div class="main-panel">
            <?php require('header_nav.php'); ?>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                    <?php
                        if(isset($_REQUEST['module']) && isset($_REQUEST['action']) && array_key_exists($_REQUEST['module'], $pagedata['page_info']['module']) && array_key_exists($_REQUEST['action'], $pagedata['page_info']['page']) && file_exists("pages/".$_REQUEST['module']."/".$_REQUEST['action'].".php")) {
                            require_once("pages/".$_REQUEST['module']."/".$_REQUEST['action'].".php");
                        }
                        else {
                            #echo "<pre>";
                            #print_r($pagedata['page_info']);
                            echo "<h3 class='col-md-12' style='text-align:center'><b>This file { <font color=red>".$_REQUEST['action'].".php</font> } does not exists into { pages/".$_REQUEST['module']."/ } dir</b></h3>";
                        }
                    ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php
    require('theme_setting.php');
    require('footer.php');
?>