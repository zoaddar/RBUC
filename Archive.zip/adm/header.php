<?php
    $header = file_get_contents('header.html');
    $favicon = 'assets/img/favicon.png';

    if(substr($_SERVER['PHP_SELF'], -9, 5) == "login") {
        require('../app/functions.php');
        $func = new Functions();
        
        $db = $func->db_connect(true);
        
        $by      = "Nixtec Systems";
        $url     = "https://www.nixtecsys.com";
        $bgcolor = "black";
        $bgimg   = "login.jpg";

        $res = $db->query("SELECT * FROM ".PREFIX."page WHERE pageName='login';");
        if($res) {
            $pinfo = $res->fetch_assoc();
            $bgcolor = $pinfo['background_color'];
            $bgimg = $pinfo['background_image'];
            $header = str_replace("_PAGE_TITLE_", $pinfo['pageTitle'], $header);
            $header = str_replace("_FAVICON_", $favicon, $header);
            $header = str_replace("_KEYWORD_", $pinfo['keyWord'], $header);
            $header = str_replace("_DESCRIPTION_", $pinfo['description'], $header);
            $header = str_replace("_CUSTOM_CSS_", ($pinfo['custom_css']!='') ? "<style>".$pinfo['custom_css']."</style>" : '', $header);

            $Footer = json_decode($pinfo['extra'], true);
            $loginFooterMenu = $Footer['loginFooterMenu'];
            $by  = $Footer['copyright']['BY'];
            $url = $Footer['copyright']['URL'];
        }
        $func->db_connect(false);
    }
    else {
        if(!isset($_REQUEST['module']) && !isset($_REQUEST['action'])) header('location: login.php');
        require('../app/functions.php');
		require('../app/mapping.php');
        $func = new Functions();
        // session destroy then logout
        if(isset($_REQUEST['logout'])) $func->logout();
        if(!$func->is_logged_in()) header('location: login.php');

        $_SESSION["previouspage"] = isset($_SESSION["previouspage"]) && isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : FORM_ACTION;

        $pagedata = $func->get_menu();
        $sidebarmenu = array();
        if(isset($_REQUEST['module']) && isset($_REQUEST['action']) && array_key_exists($_REQUEST['module'], $pagedata['page_info']['module']) && array_key_exists($_REQUEST['action'], $pagedata['page_info']['page']) && file_exists("pages/".$_REQUEST['module']."/".$_REQUEST['action'].".php")) {
            $sidebarmenu = $pagedata['menu'];
            $pinfo = $pagedata['page_info']['page'][$_REQUEST['action']];
            $uinfo = $pagedata['user_info'];
            $activeThemeOptions = json_decode($uinfo['themeOptions']);
            $themeOptions = $func->ThemeOptions("fetch");
            $sidebar_filter_arr = explode(",", $themeOptions['sidebar_filter']);
            $sidebar_bg_arr = explode(",", $themeOptions['sidebar_bg']);
            $sidebar_img_arr = explode(",", $themeOptions['sidebar_img']);

            $sidebar_filter = (in_array($activeThemeOptions->sidebarFilter, $sidebar_filter_arr)) ? $activeThemeOptions->sidebarFilter : 'rose';
            $sidebar_bg = (in_array($activeThemeOptions->sidebarBG, $sidebar_bg_arr)) ? $activeThemeOptions->sidebarBG : 'black';
            $sidebarImg = (in_array($activeThemeOptions->sidebarImg, $sidebar_img_arr)) ? $activeThemeOptions->sidebarImg : 'assets/img/sidebar-2.jpg';
            $sidebarMini = ($activeThemeOptions->sidebarMini!='' ) ? $activeThemeOptions->sidebarMini : '';
            $sidebarImgOpt = ($activeThemeOptions->sidebarImgOpt == 1) ? $sidebarImg : '';

            $colors = array("azure" => "info", "green" => "success", "orange" => "warning"); 
            $component_color = array_key_exists($sidebar_filter, $colors) ? $colors[$sidebar_filter] : $sidebar_filter;

            $user    = $uinfo['user'];
            $favicon = $uinfo['favicon'];
            $userImg = $uinfo['photo'];
            $company = $uinfo['company'];
            $logo    = $uinfo['logo'];
            $bgcolor = $pinfo['background_color'];
            $bgimg   = $pinfo['background_image'];

            $header = str_replace("_PAGE_TITLE_", $pinfo['pageTitle'], $header);
            $header = str_replace("_FAVICON_", $favicon, $header);
            $header = str_replace("_KEYWORD_", $pinfo['keyWord'], $header);
            $header = str_replace("_DESCRIPTION_", $pinfo['description'], $header);
            $header = str_replace("_CUSTOM_CSS_", ($pinfo['custom_css']!='') ? "<style>".$pinfo['custom_css']."</style>" : '', $header);
        }
        else {
            $header .= file_get_contents("pages/404.html");

            $header = str_replace("_PAGE_TITLE_", "404 | Page not found", $header);
            $header = str_replace("_FAVICON_", "", $header);
            $header = str_replace("_CUSTOM_CSS_", '', $header);

            $error  = (!array_key_exists($_REQUEST['module'], $pagedata['page_info']['module'])) ? ucfirst($_REQUEST['module'])."</font> } module " : ucfirst($_REQUEST['action'])."</font> } page ";
            $header = str_replace("_ERROR_DESC_", "There is no permission to access { <font color=red>".$error.".<br><br><a href='".$_SESSION['previouspage']."'>Back</a>", $header);

            die($header);
        }
    }
    echo $header;
?>