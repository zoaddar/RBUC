<?php require('header.php');?>

<body class="off-canvas-sidebar">
    <div class="wrapper wrapper-full-page">
        <div class="page-header login-page header-filter" filter-color="<?php echo $bgcolor;?>" style="background-image: url('assets/img/<?php echo $bgimg;?>'); background-size: cover; background-position: top center;">
            <!--   you can change the color of the filter page using: data-color="blue | purple | green | orange | red | rose " -->
            <div class="container">
                <div id="loader">
                    <svg width="90" height="90">       
                        <image xlink:href="assets/img/loader.svg" src="assets/img/loader.gif" width="90" height="90"/>    
                    </svg>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-8 ml-auto mr-auto">
                    <?php
                        $login = new stdClass();
                        $login->type = "hidden";
                        $login->name = "login";
                        $login->title = "Login";
                        $rows[] = array($login);

                        $user = new stdClass();
                        $user->title = "User ID";
                        $user->type = "text";
                        $user->value = "admin";
                        $user->name = "user";
                        $user->required = "required";
                        $user->autocomplete = "off";
                        $user->col_obj = "col-md-12";
                        $rows[] = array($user);

                        $pass = new stdClass();
                        $pass->title = "Password";
                        $pass->type = "password";
                        $pass->value = "1";
                        $pass->name = "pass";
                        $pass->required = "required";
                        $pass->autocomplete = "off";
                        $pass->col_obj = "col-md-12";
                        $rows[] = array($pass);

                        $submit = new stdClass();
                        $submit->value = "Lets Go";
                        $submit->type = "submit";
                        $submit->name = "login";
                        $submit->class = "btn-fill btn-rose text-right";
                        $card_footer_content[] = array($submit);

                        $card = new stdClass();
                        $card->type = "card";
                        $card->card_start = true;
                        $card->card_icon = "vpn_key";
                        $card->card_color = "rose";
                        $card->card_title = "Login";
                        $card->card_end = true;
                        $card->event = 'onsubmit="AJAXSubmit(this); return false;"';
                        $card->form = array("form_login", "../app/isset.php");
                        $card->card_body = $rows;
                        $card->card_footer_class = "pull-right";
                        $card->card_footer_content = $card_footer_content;

                        echo gen_card($card);
                    ?>
                    </div>
                </div>
            </div>

            <footer class="footer">
                <div class="container">
                    <nav class="float-left">
                        <ul>
                        <?php
                            if(is_array($loginFooterMenu) && count($loginFooterMenu)>0) {
                                foreach($loginFooterMenu as $mdata) {
                                    echo "<li><a href='".$mdata['mURL']."'>".$mdata['mName']."</a></li>";
                                }
                            }
                        ?>
                        </ul>
                    </nav>
                    <div class="copyright float-right">&copy;<script>document.write(new Date().getFullYear())</script>, made with <i class="material-icons">favorite</i> by <a href="<?php echo $url;?>" target="_blank"><?php echo $by;?></a> for a better service.</div>
                </div>
            </footer>
        </div>
    </div>
 
<?php require('footer.php'); ?>

<script>
    $(document).ready(function (e) {
        setFormValidation('#form_login');

        // after 1000 ms we add the class animated to the login/register card
        md.checkFullPageBackgroundImage();
            setTimeout(function() {
            $('.card').removeClass('card-hidden');
        }, 700);
    });
</script>