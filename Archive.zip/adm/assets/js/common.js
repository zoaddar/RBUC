//Sidebar settings
$(document).ready(function() {
    $('#sidebarMini').on('change', function() {
        var val = ($(this).is(':checked') ? 'sidebar-mini' : '');
        LoadData('Operation failed', '../app/isset.php?sidebar=true', "sidebarOpt=sidebarMini|"+val);
        location.reload();
    });
    $('#sidebarImgOpt').on('change', function() {
        var val = ($(this).is(':checked') ? '1' : '0');
        LoadData('Operation failed', '../app/isset.php?sidebar=true', "sidebarOpt=sidebarImgOpt|"+val);
    });
    $('.fixed-plugin .uitheme').click(function() {
        $(this).parent('li').siblings().removeClass('actv');
        $(this).parent('li').addClass('actv');

        var theme = $(this).parent('li').attr('id');
        LoadData('Operation failed', '../app/isset.php?uitheme=true', "activetheme="+theme);
    });
});
function sidebar(option, x) {
    LoadData('Operation failed', '../app/isset.php?sidebar=true', "sidebarOpt="+option+"|"+x);
}

// Auto Close Alert
function auto_close_alert(TITLE, TXT, TIMER, TYPE, BTN) {
    if(TYPE === 'warning') TXT = '<font color="red">'+TXT+'</font>';
    swal({
        title: TITLE,
        html: TXT,
        timer: TIMER,
        type: TYPE,
        showConfirmButton: BTN
    }).catch(swal.noop);
}

// Ajax Request
function LoadData(errorType, Url, params, callback="") {
    if (params.length == 0) {
        auto_close_alert('Failed', 'Invalid Input', 100000, 'warning', true);
        return;
    }
    else {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var obj = JSON.parse(this.responseText);
                
                if(obj.error) {
                    auto_close_alert(errorType, obj.error, 3000, 'warning', true);
                }
                else if(obj.success) {
                    return;
                }
                else {
                    callback(this);
                }
            }
        };
        xmlhttp.open("POST", Url);
        xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xmlhttp.send(params);
    }
}
// check base64
function isBase64(str) {
    if (str ==='' || str.trim() ===''){ return false; }
    try {
        return btoa(atob(str)) == str;
    } catch (err) {
        return false;
    }
}

// Form Validation
function setFormValidation(id) {
    $(id).validate({
        highlight: function(element) {
            $(element).closest('.form-group').removeClass('has-success').addClass('has-danger');
            $(element).closest('.form-check').removeClass('has-success').addClass('has-danger');
        },
        success: function(element) {
            $(element).closest('.form-group').removeClass('has-danger').addClass('has-success');
            $(element).closest('.form-check').removeClass('has-danger').addClass('has-success');
        },
        errorPlacement: function(error, element) {
            $(element).closest('.form-group').append(error);
        },
    });
}
// Disable scroll when focused on a number input.
jQuery(document).ready( function($) {
    $('form').on('focus', 'input[type=number]', function(e) {
        $(this).on('wheel', function(e) {
            e.preventDefault();
        });
    });
    // Restore scroll on number inputs.
    $('form').on('blur', 'input[type=number]', function(e) {
        $(this).off('wheel');
    });
    // Disable up and down keys.
    $('form').on('keydown', 'input[type=number]', function(e) {
        if ( e.which == 38 || e.which == 40 )
        e.preventDefault();
    });
});
