<?php
    if(!$_SESSION['loggedin'] || $_SESSION['loggedin']!=true) header('location: ../../login.php');

    $rows = array();

    $hidden = new stdClass();
    $hidden->type = "hidden";
    $hidden->name = "hiddendata";
    $hidden->value = "hidden";
    $hidden->title = "Hidden";
    $hidden->required = "required";
    $rows[] = array($hidden);

    $number = new stdClass();
    $number->title = "NID *";
    $number->value = "12";
    $number->type = "number";
    $number->range = "[10, 999]";
    $number->name = "nid";
    $number->required = "required";
    $number->col_obj = "col-md-4";
    #$rows[] = array($number);

    $text = new stdClass();
    $text->title = "First Name *";
    $text->value = "Abdul";
    $text->type = "text";
    $text->minLength = "5";
    $text->maxLength = "20";
    $text->name = "fst_name";
    $text->required = "required";
    $text->col_obj = "col-md-4";

    $text1 = new stdClass();
    $text1->title = "Last Name *";
    $text1->value = "Kader";
    $text1->type = "text";
    $text1->minLength = "5";
    $text1->maxLength = "20";
    $text1->name = "lst_name";
    $text1->required = "required";
    $text1->col_obj = "col-md-4";
    $rows[] = array($number, $text, $text1);

    $checkbox = new stdClass();
    $checkbox->name = "checkbox";
    $checkbox->type  = "checkbox";
    $checkbox->title = "Educational Qualification";
    $checkbox->col_obj = "col-md-6";
    $checkbox->title_class = "col-md-4 col-form-label label-checkbox";
    $checkbox->title_col = "col-md-8 checkbox-radios";
    $checkbox->class = "form-check-inline"; # form-check-inline
    $checkbox->value ='[{"display":"User","value":"user"},{"display":"HSC","value":"hsc"}]';

    $radio = new stdClass();
    $radio->name  = "radio";
    $radio->type  = "radio";
    $radio->checked  = "2";
    $radio->title = "Gender";
    $radio->col_obj = "col-md-6";
    $radio->title_class = "col-md-2 col-form-label label-checkbox";
    $radio->title_col = "col-md-6 checkbox-radios";
    $radio->class = "form-check-inline"; # form-check-inline
    $radio->value = '[{"display":"Male","value":"1"},{"display":"Female","value":"2"}]';
    $rows[] = array($checkbox, $radio);


    $select = new stdClass();
    $select->name = "select";
    $select->type  = "select";
    #$select->selected  = "hsc";
    $select->col_obj = "col-md-6";
    $select->class = "selectpicker";
    $select->required = "required";
    $select->data_size = "7";
    $select->data_style = "btn btn-primary btn-round"; #select-with-transition
    $select->title = "Country";
    $select->value = '[{"display":"Ban","value":"B"},{"display":"Ind","value":"I"}]';


    $multipleselect = new stdClass();
    $multipleselect->name = "multipleselect";
    $multipleselect->type  = "select";
    $multipleselect->multiple  = true;
    $multipleselect->col_obj = "col-md-6";
    $multipleselect->class = "selectpicker";
    $multipleselect->data_size = "7";
    $multipleselect->data_style = "btn btn-primary btn-round"; #select-with-transition
    $multipleselect->title = "Select Division";
    $multipleselect->value = '[{"display":"Dhaka","value":"D"},{"display":"Rajshahi","value":"R"},{"display":"Comilla","value":"C"}]';
    $rows[] = array($select, $multipleselect);


    $textarea = new stdClass();
    $textarea->title = "Address";
    $textarea->type = "textarea";
    $textarea->rows = "5";
    $textarea->name = "textarea";
    $textarea->col_obj = "col-md-12";
    $rows[] = array($textarea);


    $submit = new stdClass();
    $submit->value = "Submit";
    $submit->type = "submit";
    $submit->name = "submit";
    $submit->class = "btn-fill btn-rose";
    $submit->col_obj = "col-md-12";
    $card_footer_content[] = array($submit);

    $card = new stdClass();
    $card->type = "card";
    $card->card_start = true;
    #$card->card_class = "card card-login card-hidden";
    $card->card_icon = "contacts";
    $card->card_color = "rose";
    $card->card_title = "Contacts Form";
    $card->card_end = true;
    $card->form = array("form_id", "#");
    $card->card_body = $rows;
    $card->card_footer_class = "text-right";
    $card->card_footer_content = $card_footer_content;

    // echo "<pre>";
    // print_r($rows);
    echo "<div class=\"col-md-8\">";
        echo gen_card($card);
    echo "</div>";


    if(isset($_REQUEST['form_submit'])) {
        echo "<pre>";
        $formdata = form_data($_REQUEST);
        print_r($formdata);
    }

    // echo "<pre>";
    // print_r($_SESSION);
?>