<div id="loader">
    <svg width="90" height="90">       
        <image xlink:href="assets/img/loader.svg" src="assets/img/loader.gif" width="90" height="90"/>    
    </svg>
</div>

<?php
if(!$_SESSION['loggedin'] || $_SESSION['loggedin']!=true) header('location: ../../login.php');

if(isset($_REQUEST['module']) && $_REQUEST['module']=="home" && isset($_REQUEST['action']) && $_REQUEST['action']=="profile") {
    $puser  = $_SESSION['user_inf']->user;
    $result = $func->get_user($puser, "*", true);
    $rows   = array();

    $own = new stdClass();
    $own->title = "Update";
    $own->type = "hidden";
    $own->value = "own";
    $own->name = "update";

    $user = new stdClass();
    $user->title = "User Name";
    $user->type = "text";
    $user->value = $result["user"];
    $user->disabled = "disabled";
    $user->col_obj = "col-md-6";

    $name = new stdClass();
    $name->name = "chgname";
    $name->title = "Full Name";
    $name->type = "text";
    $name->value = $result["name"];
    $name->required = "required";
    $name->autocomplete = "nope";
    $name->col_obj = "col-md-6";

    $email = new stdClass();
    $email->name = "chgemail";
    $email->title = "E-mail";
    $email->type = "email";
    $email->value = $result["email"];
    $email->required = "required";
    $email->autocomplete = "nope";
    $email->col_obj = "col-md-6";

    $mobile = new stdClass();
    $mobile->name = "chgmob";
    $mobile->title = "Mobile";
    $mobile->type = "tel";
    $mobile->value = $result["mobile"];
    $mobile->required = "required";
    $mobile->autocomplete = "nope";
    $mobile->pattern = "[0-9]{3}-[0-9]{3}-[0-9]{3}-[0-9]{4}";
    $mobile->col_obj = "col-md-6";

    $address = new stdClass();
    $address->name = "chgaddress";
    $address->title = "Address";
    $address->value = $result["address"];
    $address->type = "textarea";
    $address->rows = "5";
    $address->col_obj = "col-md-12";

    $img = new stdClass();
    $img->type = "img";
    $img->name = "chgphoto";
    $img->width = "120px";
    $img->class = "break";
    $img->exist_img = $result["photo"];
    $img->selectbtn = "btn-$component_color btn-sm btn-square";
    $img->removebtn = "btn-danger btn-sm btn-square";
    $img->col_obj = "col-md-12";

    $submit = new stdClass();
    $submit->value = "Update";
    $submit->type = "submit";
    $submit->name = "submit";
    $submit->class = "btn-fill btn-$component_color";
    $card_footer_content[] = array($submit);

    $row[] = array($own, $user, $name, $email, $mobile, $address, $img);

    $card1 = new stdClass();
    $card1->type = "card";
    $card1->card_start = true;
    $card1->card_icon = "perm_identity";
    $card1->card_color = $component_color;
    $card1->card_title = "Edit Profile";
    $card1->card_end = true;
    $card1->card_body = $row;
    $card1->event = 'onsubmit="AJAXSubmit(this); return false;"';
    $card1->form = array("form_update_own", "../app/isset.php".FORM_ACTION);
    $card1->card_footer_class = "pull-right";
    $card1->card_footer_content = $card_footer_content;

    echo '<div class="col-md-7">';
        echo gen_card($card1);
    echo '</div>';

    $tags = array();

    $h6 = new stdClass();
    $h6->type  = "tag";
    $h6->label  = "h6";
    $h6->class = "card-category text-$component_color";
    $h6->content = $result['role'];
    $h6->end = true;
    $tags[] = array($h6);

    $h4 = new stdClass();
    $h4->type  = "tag";
    $h4->label  = "h6";
    $h4->class = "card-title break";
    $h4->content = $result['name'];
    $h4->end = true;
    $tags[] = array($h4);

    $passrow = array();

    $chp_own = new stdClass();
    $chp_own->title = "Update";
    $chp_own->type = "hidden";
    $chp_own->value = "chp_own";
    $chp_own->name = "update";

    $o_pass = new stdClass();
    $o_pass->name = "o_pass";
    $o_pass->title = "Old Password";
    $o_pass->type = "password";
    $o_pass->required = "required";
    $o_pass->autocomplete = "nope";
    $o_pass->col_obj = "col-md-12 text-left";

    $n_pass = new stdClass();
    $n_pass->name = "n_pass";
    $n_pass->id = "n_pass";
    $n_pass->title = "New Password";
    $n_pass->type = "password";
    $n_pass->required = "required";
    $n_pass->autocomplete = "nope";
    $n_pass->col_obj = "col-md-12 text-left";

    $r_pass = new stdClass();
    $r_pass->name = "r_pass";
    $r_pass->title = "Retype Password";
    $r_pass->type = "password";
    $r_pass->required = "required";
    $r_pass->equalTo = "n_pass";
    $r_pass->autocomplete = "nope";
    $r_pass->col_obj = "col-md-12 text-left";

    $passrow[] = array($chp_own, $o_pass, $n_pass, $r_pass);

    $modal = new stdClass();
    $modal->type  = "modal";
    $modal->title  = "Change Password";
    $modal->btn_value  = "Change Password";
    $modal->btn_class  = "btn-fill btn-$component_color break";
    $modal->event = 'onsubmit="AJAXSubmit(this); return false;"';
    $modal->form  = array("form_chp_own", "../app/isset.php".FORM_ACTION);
    $modal->form_btn_class  = "btn-fill btn-$component_color";
    $modal->body = $passrow;
    $tags[] = array($modal);


    $td1 = new stdClass(); $td1->value = "Services"; $td1->class = "text-success text-left";
    $td2 = new stdClass(); $td2->value = $result['additional_info']; $td2->class = "text-dark text-left";
    $rows[] = array($td1,$td2);
    $td1 = new stdClass(); $td1->value = "Refered by"; $td1->class = "text-success text-left";
    $td2 = new stdClass(); $td2->value = $result['refered_by']; $td2->class = "text-dark text-left";
    $rows[] = array($td1,$td2);
    $td1 = new stdClass(); $td1->value = "Email"; $td1->class = "text-success text-left";
    $td2 = new stdClass(); $td2->value = $result['email']; $td2->class = "text-dark text-left";
    $rows[] = array($td1,$td2);
    $td1 = new stdClass(); $td1->value = "Mobile"; $td1->class = "text-success text-left";
    $td2 = new stdClass(); $td2->value = $result['mobile']; $td2->class = "text-dark text-left";
    $rows[] = array($td1,$td2);
    $td1 = new stdClass(); $td1->value = "Address"; $td1->class = "text-success text-left";
    $td2 = new stdClass(); $td2->value = $result['address']; $td2->class = "text-dark text-left";
    $rows[] = array($td1,$td2);

    $card = new stdClass();
    $card->type = "card";
    $card->card_start = true;
    $card->card_class = "card card-profile";
    $card->avatar = ($result['photo']!='' && $result['photo']!= null) ? _PATH_."adm/".$result['photo'] : _PATH_."adm/assets/img/user.png";
    $card->card_end = true;
    $card->toolbar = $tags;
    $card->table = array($rows);


    echo '<div class="col-md-5">';
        echo gen_card($card);
    echo '</div>';
}
?>

<script>
    $(document).ready(function() {
        setFormValidation('#form_update_own');
        setFormValidation('#form_chp_own');
    });
</script>