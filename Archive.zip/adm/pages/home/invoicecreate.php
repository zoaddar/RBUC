<?php            
    $customers = $func->GET_DATA("customer", "acc_name AS value, acc_name AS display");

    $rows = array();
    $o_date = new stdClass();
    $o_date->type = "text";
    $o_date->name = "o_date";
    $o_date->title = "Order Date";
    $o_date->class = "datepicker";
    $o_date->label_class = "label-control";
    $o_date->required = "required";
    $o_date->autocomplete = "nope";
    $o_date->col_obj = "col-md-4";

    $acc_name = new stdClass();
    $acc_name->name = "acc_name";
    $acc_name->event = 'onchange="acc_name_evnt()"';
    $acc_name->type  = "select";
    $acc_name->data_size = "7";
    $acc_name->data_style = "select-with-transition";
    $acc_name->title = "Account Name";
    $acc_name->required = "required";
    $acc_name->value = json_encode($customers);
    $acc_name->col_obj = "col-md-8";

    $d_date = new stdClass();
    $d_date->type = "text";
    $d_date->name = "d_date";
    $d_date->title = "Delivary Date";
    $d_date->class = "datepicker";
    $d_date->label_class = "label-control";
    $d_date->required = "required";
    $d_date->autocomplete = "nope";
    $d_date->col_obj = "col-md-4";

    $acc_add = new stdClass();
    $acc_add->type = "text";
    $acc_add->name = "acc_add";
    $acc_add->id = "acc_add";
    $acc_add->title = "Address";
    $acc_add->label_class = "label-control";
    $acc_add->required = "required";
    $acc_add->autocomplete = "nope";
    $acc_add->col_obj = "col-md-8";

    $drive_link = new stdClass();
    $drive_link->type = "text";
    $drive_link->name = "drive_link";
    $drive_link->title = "Drive Link";
    $drive_link->label_class = "label-control";
    $drive_link->required = "required";
    $drive_link->autocomplete = "nope";
    $drive_link->col_obj = "col-md-6";

    $acc_phone = new stdClass();
    $acc_phone->type = "text";
    $acc_phone->name = "acc_phone";
    $acc_phone->id = "acc_phone";
    $acc_phone->title = "Account Phone";
    $acc_phone->label_class = "label-control";
    $acc_phone->required = "required";
    $acc_phone->autocomplete = "nope";
    $acc_phone->col_obj = "col-md-3";

    $acc_due = new stdClass();
    $acc_due->type = "number";
    $acc_due->name = "acc_due";
    $acc_due->id = "acc_due";
    $acc_due->title = "Due";
    $acc_due->label_class = "label-control";
    $acc_due->required = "required";
    $acc_due->autocomplete = "nope";
    $acc_due->col_obj = "col-md-3";

    $customer = new stdClass();
    $customer->type = "text";
    $customer->name = "customer";
    $customer->title = "Customer Name";
    $customer->label_class = "label-control";
    $customer->required = "required";
    $customer->autocomplete = "nope";
    $customer->col_obj = "col-md-6";

    $phone = new stdClass();
    $phone->type = "text";
    $phone->name = "phone";
    $phone->title = "Customer Phone";
    $phone->label_class = "label-control";
    $phone->required = "required";
    $phone->autocomplete = "nope";
    $phone->col_obj = "col-md-6";
    $rows[] = array($o_date, $acc_name, $d_date, $acc_add, $drive_link, $acc_phone, $acc_due, $customer, $phone);




    $card = new stdClass();
    $card->type = "card";
    $card->card_start = true;
    $card->card_icon = "shopping_cart";
    $card->card_color = $component_color;
    $card->card_title = "Add Role";
    $card->card_end = true;
    $card->card_body = $rows;
    $card->event = 'onsubmit="AJAXSubmit(this); return false;"';
    $card->form = array("form_add_role", "../app/isset.php".FORM_ACTION);
    $card->card_footer_class = "pull-left";
    // $card->card_footer_content = $card_footer_content;

    echo '<div class="col-md-12">';
        echo gen_card($card);
    echo '</div>';
?>

<script>
    $(document).ready(function() {
        $('.datepicker').datetimepicker({
            format: 'DD/MM/YYYY',
            icons: {
                previous: 'fa fa-chevron-left',
                next: 'fa fa-chevron-right',
            }
        });
        $('#acc_name').selectize({
            create: true,
            sortField: {
                field: 'text',
                direction: 'asc'
            },
            dropdownParent: 'body'
        });
    });

    function acc_name_evnt() {
        var acc_name = document.getElementById("acc_name").value;
        
        if (acc_name !=='' && acc_name.trim() !=='') {
            if(isBase64(acc_name)) {
                acc_name = JSON.parse($.base64.decode(acc_name)).value;
            }
            // alert(acc_name);

            LoadData("Loading error", '../app/isset.php?acc_name_evnt=true', "acc_name="+acc_name, callback);

            function callback(xmlhttp) {
                console.log(xmlhttp);
            }
        }
    }
</script>