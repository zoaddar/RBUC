<?php
    if(!$_SESSION['loggedin'] || $_SESSION['loggedin']!=true) header('location: ../../login.php');

    echo "<pre>";
    print_r($_SESSION);

    $additional_info = array("additionalKey" => "domain", "additionalVal" => "kader.nixtecsys.com");
    $additional_info = serialize($additional_info);
    $additional_info = base64_encode($additional_info);

    // print_r(unserialize(base64_decode($additional_info)));
?>