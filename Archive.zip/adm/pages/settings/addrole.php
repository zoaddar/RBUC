<div id="loader">
    <svg width="90" height="90">       
        <image xlink:href="assets/img/loader.svg" src="assets/img/loader.gif" width="90" height="90"/>    
    </svg>
</div>

<?php
    if(!$_SESSION['loggedin'] || $_SESSION['loggedin']!=true) header('location: ../../login.php');

    if(isset($_REQUEST['module']) && $_REQUEST['module']=="settings" && isset($_REQUEST['action']) && $_REQUEST['action']=="addrole") {
        $rows = array();

        if(isset($_REQUEST['redit']) && $_REQUEST['redit']!='') {
            $rolepermissionsarr=$permjsons = array();
            $id    = valid_input($_REQUEST['redit']);

            $roles = $func->GET_DATA("roles", "ID,Title,Description", " WHERE ID='$id'")[0];
            $rolepermissions = $func->GET_DATA("rolepermissions", "PermissionID", "WHERE RoleID='$id'");
            $permissions = $func->GET_DATA("permissions", "ID,Description", "ORDER BY Description ASC");

            foreach($rolepermissions as $r) {
                $rolepermissionsarr[] = $r['PermissionID'];
            }
            foreach($permissions as $p) {
                if(in_array($p['ID'], $rolepermissionsarr)) {
                    $permjson[] = array("value"=>$p['ID'],"display"=>$p['Description'],"checked"=>true);
                }
                else {
                    $permjson[] = array("value"=>$p['ID'],"display"=>$p['Description']);
                }
            }

            $o_role = new stdClass();
            $o_role->title = "Old Role";
            $o_role->type = "hidden";
            $o_role->name = "o_role";
            $o_role->value = $roles['Title'];

            $title = new stdClass();
            $title->title = "Role Name";
            $title->type = "text";
            $title->name = "u_title";
            $title->value = $roles['Title'];
            $title->required = "required";
            $title->autocomplete = "nope";
            $title->col_obj = "col-md-12";

            $desc = new stdClass();
            $desc->title = "Description";
            $desc->type = "text";
            $desc->value = $roles['Description'];
            $desc->name = "u_desc";
            $desc->required = "required";
            $desc->autocomplete = "nope";
            $desc->col_obj = "col-md-12";

            $perm = new stdClass();
            $perm->name = "perm";
            $perm->type  = "checkbox";
            $perm->title = "Permissions";
            $perm->title_class = "col-md-2 col-form-label label-checkbox";
            $perm->title_col = "col-md-10 checkbox-radios";
            $perm->class = "form-check"; # form-check-inline
            $perm->value = json_encode($permjson);
            $perm->col_obj = "col-md-12";

            $submit = new stdClass();
            $submit->value = "Submit";
            $submit->type = "submit";
            $submit->name = "submit";
            $submit->class = "btn-fill btn-$component_color";
            $card_footer_content[] = array($submit);

            $rows[] = array($o_role, $title, $desc, $perm);

            $card = new stdClass();
            $card->type = "card";
            $card->card_start = true;
            $card->card_icon = "contacts";
            $card->card_color = $component_color;
            $card->card_title = "Update Role";
            $card->card_end = true;
            $card->card_body = $rows;
            $card->event = 'onsubmit="AJAXSubmit(this); return false;"';
            $card->form = array("form_update_role", "../app/isset.php".FORM_ACTION);
            $card->card_footer_class = "pull-right";
            $card->card_footer_content = $card_footer_content;

            echo '<div class="col-md-8">';
                echo gen_card($card);
            echo '</div>';
        }
        else {
            $thead = array();
            $th1 = new stdClass(); $th1->thd_cls = "card-header-$component_color text-white";
            $th2 = new stdClass(); $th2->label = "ID";
            $th3 = new stdClass(); $th3->label = "Title"; 
            $th4 = new stdClass(); $th4->label = "Description";
            $thead[] = array($th1,$th2,$th3,$th4);


            $modaldate = array();
            $mtitle = new stdClass();
            $mtitle->title = "Role Name";
            $mtitle->type = "text";
            $mtitle->name = "title";
            $mtitle->required = "required";
            $mtitle->autocomplete = "nope";
            $mtitle->col_obj = "col-md-12 text-left";

            $mdesc = new stdClass();
            $mdesc->title = "Description";
            $mdesc->type = "text";
            $mdesc->name = "desc";
            $mdesc->required = "required";
            $mdesc->autocomplete = "nope";
            $mdesc->col_obj = "col-md-12 text-left";

            $modaldate[] = array($mtitle, $mdesc);

            $modals = array();
            $modal = new stdClass();
            $modal->type  = "modal";
            $modal->btn_value = "Add Role";
            $modal->btn_class = "btn-$component_color btn-sm active";
            $modal->title  = "Add New Role";
            $modal->event = 'onsubmit="AJAXSubmit(this); return false;"';
            $modal->form  = array("form_add_role", "../app/isset.php".FORM_ACTION."&add=addrole");
            $modal->form_btn_class  = "btn-fill btn-$component_color";
            $modal->body = $modaldate;

            $title = new stdClass();
            $title->title = "Permission Name";
            $title->type = "text";
            $title->name = "ptitle";
            $title->required = "required";
            $title->autocomplete = "nope";
            $title->col_obj = "col-md-12 text-left";

            $desc = new stdClass();
            $desc->title = "Description";
            $desc->type = "text";
            $desc->name = "pdesc";
            $desc->required = "required";
            $desc->autocomplete = "nope";
            $desc->col_obj = "col-md-12 text-left";

            $rows[] = array($title, $desc);

            $modal1 = new stdClass();
            $modal1->type  = "modal";
            $modal1->id  = "modal1";
            $modal1->btn_value  = "Add Permission";
            $modal1->title  = "Add New Permission";
            $modal1->btn_class  = "btn-$component_color btn-sm active";
            $modal1->event = 'onsubmit="AJAXSubmit(this); return false;"';
            $modal1->form  = array("form_add_perm", "../app/isset.php".FORM_ACTION."&add=addpermission");
            $modal1->form_btn_class  = "btn-fill btn-$component_color";
            $modal1->body = $rows;

            $modals[] = array($modal, $modal1);

            $card = new stdClass();
            $card->type = "card";
            $card->card_start = true;
            $card->card_icon = "assignment";
            $card->card_color = $component_color;
            $card->card_title = "Manage Roles";
            $card->card_end = true;
            $card->toolbar = $modals;
            $card->table = array($thead, "datatables", true);

            echo gen_card($card);
        }
    }
?>


<script>
    $(document).ready(function() {
        var dataTable = $('#datatables').DataTable({
        "processing": true,
        "serverSide": true,
            "ajax":{
                url :"../app/isset.php",
                type: "post",
                data: { "roles_tbl" : <?php echo "'".$_SESSION['user_inf']->user."'";?> },
                error: function() {
                    $("#datatbl_err").append('<tbody class="error"><tr><th colspan="30">No data found in the server</th></tr></tbody>');
                    $("#datatables_processing").css("display","none");
                }
            }
        });
        // Form Validation
        setFormValidation('#form_add_role');
        setFormValidation('#form_update_role');
        setFormValidation('#form_add_perm');
    });
</script>