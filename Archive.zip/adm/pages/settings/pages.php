<div id="loader">
    <svg width="90" height="90">       
        <image xlink:href="assets/img/loader.svg" src="assets/img/loader.gif" width="90" height="90"/>    
    </svg>
</div>

<?php
    if(!$_SESSION['loggedin'] || $_SESSION['loggedin']!=true) header('location: ../../login.php');

    if(isset($_REQUEST['module']) && $_REQUEST['module']=="settings" && isset($_REQUEST['action']) && $_REQUEST['action']=="pages") {
        $rows = array();
        $user = $_SESSION['user_inf']->user;
        $modules = json_encode($func->GET_DATA("module", "id AS value, title AS display", " WHERE publish=1"));

        if(isset($_REQUEST['pedit']) && $_REQUEST['pedit']!='') {
            $pid = valid_input($_REQUEST['pedit']);
            $pagedata = $func->GET_DATA("page", "*", " WHERE id='$pid'")[0];

            if($pagedata['mini'] == "" || $pagedata['mini'] == null) {
                $moduledata = $func->GET_DATA("module", "*", " WHERE id='$pagedata[module]'")[0];
                
                $u_mod = new stdClass();
                $u_mod->name = "u_mod";
                $u_mod->title = "Update Module";
                $u_mod->type = "hidden";
                $u_mod->value = $moduledata['id'];

                $status = new stdClass();
                $status->name = "publish";
                $status->type  = "select";
                $status->class = "selectpicker";
                $status->data_size = "7";
                $status->data_style = "select-with-transition";
                $status->title = "Select Status";
                $status->required = "required";
                $status->selected = $moduledata['publish'];
                $status->value = json_encode($user_status);
                $status->col_obj = "col-md-6";

                $u_m_icon = new stdClass();
                $u_m_icon->name = "u_m_icon";
                $u_m_icon->type  = "select";
                $u_m_icon->data_size = "7";
                $u_m_icon->data_style = "select-with-transition";
                $u_m_icon->title = "Module Icon";
                $u_m_icon->required = "required";
                $u_m_icon->selected = $moduledata['icons'];
                $u_m_icon->value = $icons;
                $u_m_icon->col_obj = "col-md-6";

                $u_m_title = new stdClass();
                $u_m_title->name = "u_m_title";
                $u_m_title->title = "Module Title";
                $u_m_title->type = "text";
                $u_m_title->value = $moduledata['title'];
                $u_m_title->required = "required";
                $u_m_title->autocomplete = "nope";
                $u_m_title->col_obj = "col-md-12";

                $submit = new stdClass();
                $submit->value = "Submit";
                $submit->type = "submit";
                $submit->name = "submit";
                $submit->class = "btn-fill btn-$component_color";
                $card_footer_content[] = array($submit);

                $row[] = array($u_mod, $status, $u_m_icon, $u_m_title);

                $card = new stdClass();
                $card->type = "card";
                $card->card_start = true;
                $card->card_icon = "assignment";
                $card->card_color = $component_color;
                $card->card_title = "Update Module";
                $card->card_end = true;
                $card->card_body = $row;
                $card->event = 'onsubmit="AJAXSubmit(this); return false;"';
                $card->form = array("form_update_module", "../app/isset.php".FORM_ACTION);
                $card->card_footer_class = "pull-left";
                $card->card_footer_content = $card_footer_content;

                echo '<div class="col-md-12">';
                    echo gen_card($card);
                echo '</div>';
            }
            else {                
                $u_page = new stdClass();
                $u_page->name = "u_page";
                $u_page->title = "Update Module";
                $u_page->type = "hidden";
                $u_page->value = $pagedata['id'];

                $status = new stdClass();
                $status->name = "publish";
                $status->type  = "select";
                $status->class = "selectpicker";
                $status->data_size = "7";
                $status->data_style = "select-with-transition";
                $status->title = "Select Status";
                $status->required = "required";
                $status->selected = $pagedata['publish'];
                $status->value = json_encode($user_status);
                $status->col_obj = "col-md-6";

                $p_module = new stdClass();
                $p_module->name = "u_pmodule";
                $p_module->type  = "select";
                $p_module->class = "selectpicker";
                $p_module->data_size = "7";
                $p_module->data_style = "select-with-transition";
                $p_module->title = "Select Module";
                $p_module->selected = $pagedata['module'];
                $p_module->required = "required";
                $p_module->value = $modules;
                $p_module->col_obj = "col-md-6";
        
                $p_title = new stdClass();
                $p_title->name = "u_p_title";
                $p_title->title = "Page Title";
                $p_title->value = $pagedata['pageTitle'];
                $p_title->type = "text";
                $p_title->required = "required";
                $p_title->autocomplete = "nope";
                $p_title->col_obj = "col-md-6";
        
                $keyword = new stdClass();
                $keyword->name = "u_keyword";
                $keyword->title = "Keyword";
                $keyword->value = $pagedata['keyWord'];
                $keyword->type = "text";
                $keyword->required = "required";
                $keyword->autocomplete = "nope";
                $keyword->col_obj = "col-md-6";
        
                $description = new stdClass();
                $description->name = "u_description";
                $description->value = $pagedata['description'];
                $description->title = "Page Description";
                $description->type = "textarea";
                $description->rows = "5";
                $description->col_obj = "col-md-12";
        
                $css = new stdClass();
                $css->name = "u_custom_css";
                $css->title = "Custom CSS";
                $css->value = $pagedata['custom_css'];
                $css->type = "textarea";
                $css->rows = "5";
                $css->col_obj = "col-md-12";

                $submit = new stdClass();
                $submit->value = "Submit";
                $submit->type = "submit";
                $submit->name = "submit";
                $submit->class = "btn-fill btn-$component_color";
                $card_footer_content[] = array($submit);
    
                $row[] = array($u_page, $status, $p_module, $p_title, $keyword, $description, $css);
    
                $card = new stdClass();
                $card->type = "card";
                $card->card_start = true;
                $card->card_icon = "assignment";
                $card->card_color = $component_color;
                $card->card_title = "Update Page";
                $card->card_end = true;
                $card->card_body = $row;
                $card->event = 'onsubmit="AJAXSubmit(this); return false;"';
                $card->form = array("form_update_page", "../app/isset.php".FORM_ACTION);
                $card->card_footer_class = "pull-left";
                $card->card_footer_content = $card_footer_content;
    
                echo '<div class="col-md-12">';
                    echo gen_card($card);
                echo '</div>';

            }
        }
        else if(isset($_REQUEST['add']) && $_REQUEST['add']=='addpage') {
            $m_p = new stdClass();
            $m_p->name = "m_p";
            $m_p->type  = "select";
            $m_p->class = "selectpicker";
            $m_p->data_size = "7";
            $m_p->data_style = "select-with-transition";
            $m_p->title = "Select One";
            $m_p->event = 'onchange="onchange_addpage()"';
            $m_p->required = "required";
            $m_p->value = '[{"value":1,"display":"Module"},{"value":2,"display":"Page"}]';
            $m_p->col_obj = "col-md-6";

            $module = new stdClass();
            $module->name = "pmodule";
            $module->type  = "select";
            $module->class = "selectpicker";
            $module->data_size = "7";
            $module->data_style = "select-with-transition";
            $module->title = "Select Module";
            $module->required = "required";
            $module->value = $modules;
            $module->col_obj = "col-md-6 dis_none";
    
            $p_name = new stdClass();
            $p_name->name = "p_name";
            $p_name->title = "Page Name";
            $p_name->type = "text";
            $p_name->required = "required";
            $p_name->autocomplete = "nope";
            $p_name->col_obj = "col-md-6 dis_none";
    
            $p_title = new stdClass();
            $p_title->name = "p_title";
            $p_title->title = "Page Title";
            $p_title->type = "text";
            $p_title->required = "required";
            $p_title->autocomplete = "nope";
            $p_title->col_obj = "col-md-6 dis_none";

            $p_access_desc = new stdClass();
            $p_access_desc->name = "p_access_desc";
            $p_access_desc->title = "Page Access Description";
            $p_access_desc->type = "text";
            $p_access_desc->autocomplete = "nope";
            $p_access_desc->col_obj = "col-md-6 dis_none";
    
            $keyword = new stdClass();
            $keyword->name = "keyword";
            $keyword->title = "Keyword";
            $keyword->type = "text";
            $keyword->required = "required";
            $keyword->autocomplete = "nope";
            $keyword->col_obj = "col-md-6 dis_none";
    
            $description = new stdClass();
            $description->name = "description";
            $description->title = "Page Description";
            $description->type = "textarea";
            $description->rows = "5";
            $description->col_obj = "col-md-12 dis_none";
    
            $css = new stdClass();
            $css->name = "custom_css";
            $css->title = "Custom CSS";
            $css->type = "textarea";
            $css->rows = "5";
            $css->col_obj = "col-md-12 dis_none";

            $m_name = new stdClass();
            $m_name->name = "m_name";
            $m_name->title = "Module Name";
            $m_name->type = "text";
            $m_name->required = "required";
            $m_name->autocomplete = "nope";
            $m_name->col_obj = "col-md-6 dis_none";

            $m_title = new stdClass();
            $m_title->name = "m_title";
            $m_title->title = "Module Title";
            $m_title->type = "text";
            $m_title->required = "required";
            $m_title->autocomplete = "nope";
            $m_title->col_obj = "col-md-6 dis_none";

            $m_icon = new stdClass();
            $m_icon->name = "m_icon";
            $m_icon->type  = "select";
            $m_icon->data_size = "7";
            $m_icon->data_style = "select-with-transition";
            $m_icon->title = "Module Icon";
            $m_icon->required = "required";
            $m_icon->value = $icons;
            $m_icon->col_obj = "col-md-6 dis_none";

            $m_access_desc = new stdClass();
            $m_access_desc->name = "m_access_desc";
            $m_access_desc->title = "Module Access Description";
            $m_access_desc->type = "text";
            $m_access_desc->autocomplete = "nope";
            $m_access_desc->col_obj = "col-md-12 dis_none";

            $submit = new stdClass();
            $submit->value = "Submit";
            $submit->type = "submit";
            $submit->name = "submit";
            $submit->class = "btn-fill btn-$component_color";
            $card_footer_content[] = array($submit);

            $row[] = array($m_p, $module, $p_name, $p_title, $p_access_desc, $keyword, $description, $css, $m_name, $m_title, $m_icon, $m_access_desc);

            $card = new stdClass();
            $card->type = "card";
            $card->card_start = true;
            $card->card_icon = "assignment";
            $card->card_color = $component_color;
            $card->card_title = "Add Module/Page";
            $card->card_end = true;
            $card->card_body = $row;
            $card->event = 'onsubmit="AJAXSubmit(this); return false;"';
            $card->form = array("form_addpage", "../app/isset.php".FORM_ACTION);
            $card->card_footer_class = "pull-left";
            $card->card_footer_content = $card_footer_content;

            echo '<div class="col-md-12">';
                echo gen_card($card);
            echo '</div>';
        }
        else {
            $thead = array();
            $th1 = new stdClass(); $th1->thd_cls = "card-header-$component_color text-white";
            $th2 = new stdClass(); $th2->label = "ID";
            $th3 = new stdClass(); $th3->label = "Page Title"; 
            $th4 = new stdClass(); $th4->label = "Module";
            $th5 = new stdClass(); $th5->label = "Created By";
            $th6 = new stdClass(); $th6->label = "Status";
            $th7 = new stdClass(); $th7->label = "Created Date";
            $thead[] = array($th1,$th2,$th3,$th4,$th5,$th6,$th7);

            $tag = new stdClass();
            $tag->type  = "tag";
            $tag->label  = "a";
            $tag->href = "?module=settings&action=pages&add=addpage";
            $tag->class = "btn btn-$component_color btn-sm active center-block";
            $tag->content = "Add Page";
            $tag->end = true;
            $rows[] = array($tag);

            $card = new stdClass();
            $card->type = "card";
            $card->card_start = true;
            $card->card_icon = "assignment";
            $card->card_color = $component_color;
            $card->card_title = "Manage Pages";
            $card->card_end = true;
            $card->toolbar = $rows;
            $card->table = array($thead, "datatables", true);

            echo gen_card($card);
        }
    }
?>


<script>
    $(document).ready(function() {
        $('#m_icon').selectize();
        $('#u_m_icon').selectize();

        var dataTable = $('#datatables').DataTable({
        "processing": true,
        "serverSide": true,
            "ajax":{
                url :"../app/isset.php",
                type: "post",
                data: { "pages_tbl" : true },
                error: function() {
                    $("#datatbl_err").append('<tbody class="error"><tr><th colspan="30">No data found in the server</th></tr></tbody>');
                    $("#datatables_processing").css("display","none");
                }
            }
        });
        // Form Validation
        setFormValidation('#form_addpage');
        setFormValidation('#form_update_module');
        setFormValidation('#form_update_page');
    });


    function onchange_addpage() {
        var m_p = document.getElementById("m_p").value;
        var selected = JSON.parse($.base64.decode(m_p)).value;

        var pages = ["row_pmodule", "row_p_name", "row_p_title", "row_keyword", "row_description", "row_custom_css", "row_p_access_desc"];
        var modules = ["row_m_name", "row_m_title", "row_m_icon", "row_m_access_desc"];

        if(selected == 1) {
            for (var i = 0; i < pages.length; i++) {
                document.getElementById(pages[i]).style.display = 'none';
            }
            for (var i = 0; i < modules.length; i++) {
                document.getElementById(modules[i]).style.display = 'block';
            }
        }
        else if(selected == 2) {
            for (var i = 0; i < pages.length; i++) {
                document.getElementById(pages[i]).style.display = 'block';
            }
            for (var i = 0; i < modules.length; i++) {
                document.getElementById(modules[i]).style.display = 'none';
            }
        }
    }
</script>