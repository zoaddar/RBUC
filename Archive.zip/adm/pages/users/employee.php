<div id="loader">
    <svg width="90" height="90">       
        <image xlink:href="assets/img/loader.svg" src="assets/img/loader.gif" width="90" height="90"/>    
    </svg>
</div>

<?php
    if(!$_SESSION['loggedin'] || $_SESSION['loggedin']!=true) header('location: ../../login.php');

    if(isset($_REQUEST['module']) && $_REQUEST['module']=="users" && isset($_REQUEST['action']) && $_REQUEST['action']=="employee") {
        $rows = array();
        $user = $_SESSION['user_inf']->user;
        $pass = $func->get_user($user, "pass", true)['pass'];
        $auth = base64_encode($user."-".$pass);
        $roles = json_encode($func->GET_DATA("roles", "Title AS value, CONCAT(Title,' ( ',Description,' )') AS display", " WHERE ID <> 1"));

        if(isset($_REQUEST['view']) && $_REQUEST['view']!='') {
            $puser = valid_input($_REQUEST['view']);
            $result = $func->get_user($puser, "*", true);

            $update = new stdClass();
            $update->type = "hidden";
            $update->name = "updateuser";
            $update->value = "user";
            $update->title = "Update";

            $user = new stdClass();
            $user->name = "chguser";
            $user->title = "User Name";
            $user->type = "text";
            $user->value = $result["user"];
            $user->disabled = "disabled";
            $user->col_obj = "col-md-6";

            $name = new stdClass();
            $name->name = "chgname";
            $name->title = "Full Name";
            $name->type = "text";
            $name->value = $result["name"];
            $name->required = "required";
            $name->autocomplete = "nope";
            $name->col_obj = "col-md-6";

            $email = new stdClass();
            $email->name = "chgemail";
            $email->title = "E-mail";
            $email->type = "email";
            $email->value = $result["email"];
            $email->required = "required";
            $email->autocomplete = "nope";
            $email->col_obj = "col-md-6";

            $mobile = new stdClass();
            $mobile->name = "chgmob";
            $mobile->title = "Mobile";
            $mobile->type = "tel";
            $mobile->value = $result["mobile"];
            $mobile->required = "required";
            $mobile->autocomplete = "nope";
            $mobile->pattern = "[0-9]{3}-[0-9]{3}-[0-9]{3}-[0-9]{4}";
            $mobile->col_obj = "col-md-6";

            $role = new stdClass();
            $role->name = "chgrole";
            $role->type  = "select";
            $role->class = "selectpicker";
            $role->data_size = "7";
            $role->data_style = "select-with-transition";
            $role->title = "Select Role";
            $role->required = "required";
            $role->selected = $result['role'];
            $role->value = $roles;
            $role->col_obj = "col-md-6";

            $status = new stdClass();
            $status->name = "chgstatus";
            $status->type  = "select";
            $status->class = "selectpicker";
            $status->data_size = "7";
            $status->data_style = "select-with-transition";
            $status->title = "Select Status";
            $status->required = "required";
            $status->selected = $result['publish'];
            $status->value = json_encode($user_status);
            $status->col_obj = "col-md-6";

            $company = new stdClass();
            $company->name = "chgcompany";
            $company->title = "Company";
            $company->type = "text";
            $company->value = $result["company"];
            $company->autocomplete = "nope";
            $company->col_obj = "col-md-12";

            $address = new stdClass();
            $address->name = "chgaddress";
            $address->title = "Address";
            $address->value = $result["address"];
            $address->type = "textarea";
            $address->rows = "5";
            $address->col_obj = "col-md-12";

            $img = new stdClass();
            $img->type = "img";
            $img->name = "chgimg";
            $img->width = "120px";
            $img->class = "break";
            $img->exist_img = $result["photo"];
            $img->selectbtn = "btn-$component_color btn-sm btn-square";
            $img->removebtn = "btn-danger btn-sm btn-square";
            $img->col_obj = "col-md-12";

            $submit = new stdClass();
            $submit->value = "Update";
            $submit->type = "submit";
            $submit->name = "submit";
            $submit->class = "btn-fill btn-$component_color";
            $card_footer_content[] = array($submit);

            $row[] = array($update, $user, $name, $email, $mobile, $role, $status, $company, $address, $img);

            $card1 = new stdClass();
            $card1->type = "card";
            $card1->card_start = true;
            $card1->card_icon = "perm_identity";
            $card1->card_color = $component_color;
            $card1->card_title = "Edit Profile";
            $card1->card_end = true;
            $card1->card_body = $row;
            $card1->event = 'onsubmit="AJAXSubmit(this); return false;"';
            $card1->form = array("form_update_user", "../app/isset.php".FORM_ACTION);
            $card1->card_footer_class = "pull-right";
            $card1->card_footer_content = $card_footer_content;

            echo '<div class="col-md-7">';
                echo gen_card($card1);
            echo '</div>';

            #echo $profile;

            $tags = array();

            $h6 = new stdClass();
            $h6->type  = "tag";
            $h6->label  = "h6";
            $h6->class = "card-category text-$component_color";
            $h6->content = $result['role'];
            $h6->end = true;
            $tags[] = array($h6);

            $h4 = new stdClass();
            $h4->type  = "tag";
            $h4->label  = "h6";
            $h4->class = "card-title break";
            $h4->content = $result['name'];
            $h4->end = true;
            $tags[] = array($h4);

            $passrow = array();
        
            $user_pass = new stdClass();
            $user_pass->title = "Update";
            $user_pass->type = "hidden";
            $user_pass->value = $result['user'];
            $user_pass->name = "user";
        
            $o_pass = new stdClass();
            $o_pass->title = "Update";
            $o_pass->type = "hidden";
            $o_pass->value = $result['pass'];
            $o_pass->name = "o_pass";
        
            $n_pass = new stdClass();
            $n_pass->name = "n_pass";
            $n_pass->id = "n_pass";
            $n_pass->title = "New Password";
            $n_pass->type = "password";
            $n_pass->required = "required";
            $n_pass->autocomplete = "nope";
            $n_pass->col_obj = "col-md-12 text-left";
        
            $r_pass = new stdClass();
            $r_pass->name = "r_pass";
            $r_pass->title = "Retype Password";
            $r_pass->type = "password";
            $r_pass->required = "required";
            $r_pass->equalTo = "n_pass";
            $r_pass->autocomplete = "nope";
            $r_pass->col_obj = "col-md-12 text-left";
        
            $passrow[] = array($user_pass, $o_pass, $n_pass, $r_pass);
        
            $modal = new stdClass();
            $modal->type  = "modal";
            $modal->title  = "Change Password";
            $modal->btn_value  = "Change Password";
            $modal->btn_class  = "btn-fill btn-$component_color break";
            $modal->event = 'onsubmit="AJAXSubmit(this); return false;"';
            $modal->form  = array("form_chp_user", "../app/isset.php".FORM_ACTION."&update=chp_user");
            $modal->form_btn_class  = "btn-fill btn-$component_color";
            $modal->body = $passrow;
            $tags[] = array($modal);

            $td1 = new stdClass(); $td1->value = "Additional-Info"; $td1->class = "text-success text-left";
            $td2 = new stdClass(); $td2->value = $result['additional_info']; $td2->class = "text-dark text-left";
            $rows[] = array($td1,$td2);
            $td1 = new stdClass(); $td1->value = "Refered by"; $td1->class = "text-success text-left";
            $td2 = new stdClass(); $td2->value = $result['refered_by']; $td2->class = "text-dark text-left";
            $rows[] = array($td1,$td2);
            $td1 = new stdClass(); $td1->value = "Email"; $td1->class = "text-success text-left";
            $td2 = new stdClass(); $td2->value = $result['email']; $td2->class = "text-dark text-left";
            $rows[] = array($td1,$td2);
            $td1 = new stdClass(); $td1->value = "Mobile"; $td1->class = "text-success text-left";
            $td2 = new stdClass(); $td2->value = $result['mobile']; $td2->class = "text-dark text-left";
            $rows[] = array($td1,$td2);
            $td1 = new stdClass(); $td1->value = "Address"; $td1->class = "text-success text-left";
            $td2 = new stdClass(); $td2->value = $result['address']; $td2->class = "text-dark text-left";
            $rows[] = array($td1,$td2);

            $card = new stdClass();
            $card->type = "card";
            $card->card_start = true;
            $card->card_class = "card card-profile";
            $card->avatar = ($result['photo']!='' && $result['photo']!= null) ? _PATH_."adm/".$result['photo'] : _PATH_."adm/assets/img/user.png";
            $card->card_end = true;
            $card->toolbar = $tags;
            $card->table = array($rows);

            echo '<div class="col-md-5">';
                echo gen_card($card);
            echo '</div>';
        }
        else {
            $auths = new stdClass();
            $auths->type = "hidden";
            $auths->name = "auth";
            $auths->value = $auth;
            $auths->title = "Auth";

            $user = new stdClass();
            $user->title = "User Name";
            $user->type = "text";
            $user->name = "user";
            $user->required = "required";
            $user->autocomplete = "nope";
            $user->col_obj = "col-md-12";

            $pass = new stdClass();
            $pass->title = "Password";
            $pass->type = "password";
            $pass->name = "pass";
            $pass->required = "required";
            $pass->autocomplete = "nope";
            $pass->col_obj = "col-md-12";

            $role = new stdClass();
            $role->name = "role";
            $role->type  = "select";
            $role->col_obj = "col-md-12";
            $role->class = "selectpicker";
            $role->data_size = "7";
            $role->data_style = "select-with-transition"; #btn btn-$component_color btn-square
            $role->title = "Select Role";
            $role->required = "required";
            $role->value = $roles;

            $submit = new stdClass();
            $submit->value = "Submit";
            $submit->type = "submit";
            $submit->name = "submit";
            $submit->class = "btn-fill btn-$component_color";
            $card_footer_content[] = array($submit);

            $rows[] = array($auths, $user, $pass, $role);

            $modals = array();
            $modal = new stdClass();
            $modal->type  = "modal";
            $modal->title  = "Add New User";
            $modal->btn_value  = "Add User";
            $modal->btn_class  = "btn-$component_color btn-sm active";
            $modal->event = 'onsubmit="AJAXSubmit(this); return false;"';
            $modal->form  = array("form_add_user", "../app/isset.php".FORM_ACTION."&add=adduser");
            $modal->form_btn_class  = "btn-fill btn-$component_color";
            $modal->body = $rows;
            $modals[] = array($modal);

            $thead = array();
            $th1 = new stdClass(); $th1->thd_cls = "card-header-$component_color text-white";
            $th2 = new stdClass(); $th2->label = "Photo";
            $th3 = new stdClass(); $th3->label = "User"; 
            $th4 = new stdClass(); $th4->label = "Role";
            $th5 = new stdClass(); $th5->label = "Email";
            $th6 = new stdClass(); $th6->label = "Name";
            $th7 = new stdClass(); $th7->label = "Mobile";
            $th8 = new stdClass(); $th8->label = "Status";
            $th9 = new stdClass(); $th9->label = "Date Time";
            $thead[] = array($th1,$th2,$th3,$th4,$th5,$th6,$th7,$th8,$th9);

            $card = new stdClass();
            $card->type = "card";
            $card->card_start = true;
            $card->card_icon = "assignment";
            $card->card_color = $component_color;
            $card->card_title = "Manage Users";
            $card->card_end = true;
            $card->toolbar = $modals;
            $card->table = array($thead, "datatables", true);

            echo gen_card($card);
        }
    }
?>


<script>
    $(document).ready(function() {
        var dataTable = $('#datatables').DataTable({
        "processing": true,
        "serverSide": true,
            "ajax":{
                url :"../app/isset.php",
                type: "post",
                data: { "users_tbl" : <?php echo "'".$_SESSION['user_inf']->user."'";?> },
                error: function() {
                    $("#datatbl_err").append('<tbody class="error"><tr><th colspan="30">No data found in the server</th></tr></tbody>');
                    $("#datatables_processing").css("display","none");
                }
            }
        });
        // Form Validation
        setFormValidation('#form_add_user');
        setFormValidation('#form_update_user');
        setFormValidation('#form_chp_user');
    });
</script>